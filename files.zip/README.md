# ROXX Flight Controller (custom PX4 hardware)

Working directory for the ROXX quadcopter flight-controller development. The imported NxtPX4 Dual repository is preserved separately and is not modified.

## Deliverable status

| Deliverable | Status |
|---|---|
| README.md | partial |
| requirements.md | not started |
| architecture.md | not started (Stage 2) |
| hardware_audit.md | **complete (static inspection; ERC/DRC and netlist outstanding)** |
| interface_specification.md | not started |
| power_tree.md | not started |
| firmware_integration.md | not started |
| validation_plan.md | not started |
| change_log.md | partial |
| KiCad project, BOM, libraries | blocked: awaiting approved architecture |

## Stage

STAGE 1 done. Next: STAGE 2 (architecture, PX4 target verification, power tree).

## Open decision

Concept image uses the original NxtPX4 V2 plus a custom HAT. The brief asks for a new ROXX flight-controller PCB. Which is the intended path?
