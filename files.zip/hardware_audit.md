# ROXX Flight Controller: Hardware Audit of Imported Repository

Status: **STAGE 1 complete (static inspection only). ERC/DRC not run. Nothing in the original repository was modified.**

- Archive: `Nxt-FC-Hardware-NxtDual.zip`, SHA-256 `41fca550abf2cc6b457360ad163caec9322b053a333101f1fb9580a81ef9f8a2`
- Inspected from a read-only extracted copy; the original upload is untouched.
- Method: Python s-expression parse of the `.kicad_sch`, `.kicad_pcb`, `.kicad_pro`; CubeMX `.ioc`; pinout `.xlsx`. `kicad-cli` is not installed in this sandbox, so no netlist export, ERC or DRC was possible.

## 1. What the repository is

| Item | Finding |
|---|---|
| Design | NxtPX4 V2 "Dual": small STM32H7 flight controller (HKUST UAV group design, produced commercially by MicoAir) |
| KiCad format | Schematic v20230121, PCB v20221018 (KiCad 7-era files) |
| Schematic | Single flat sheet, A2, 153 non-power symbols, 83 distinct net labels. Title block: "NxtPX4", 2023-03-03, rev "V1.0。1" |
| PCB | 4-layer (F.Cu / In1 / In2 / B.Cu), 0.982 mm total, 133 nets, 137 footprints, 1087 track segments, 296 vias, 431 zones. Title block dated 2023-12-11. Parsed outline about 33 x 27 mm (vendor lists 27 x 32 x 8 mm) |
| Firmware | **None in the archive.** README "Getting start" sections are empty headings. A `.ioc` exists but is a pin-planning file |
| Production files | Only front/back courtyard PDFs. No Gerbers, no BOM, no pick-and-place |
| Libraries | Project symbol lib (`NxtPX4_Symbol.kicad_sym`), 70+ footprints (`NxtPX4.pretty`), 24 STEP models |

## 2. Architecture as designed

| Block | Implementation (from schematic / pinout xlsx) |
|---|---|
| MCU | STM32H743VIH6, TFBGA100, 2 MB flash, 1 MB RAM (per xlsx header) |
| Clocks | 16 MHz oscillator (Y1, SG-210STF) for HSE per xlsx; 32.768 kHz crystal (Y2) for LSE |
| IMU x2 | BMI088 on SPI1 (PA5/6/7, CS PA2 accel / PA3 gyro, DRDY PA0/PA1) and BMI088 on SPI4 (PE2/5/6, CS PC13 accel and PC2 gyro per xlsx, DRDY PE3/PE4). Separate buses give real sensor redundancy |
| Barometer | SPL06 on I2C1 (PB6/PB7), DRDY PB5. Single barometer |
| Storage | microSD on SDMMC1 4-bit (PC8-12, PD2). W25Q128JVS on SPI2 (PD3, PB14, PC3, CS PD4); nets are labelled "FRAM" but the part is NOR flash, so the naming is inconsistent |
| Motor outputs | 8 timer outputs: TIM1 CH1-4 (PE9/11/13/14), TIM2 CH3-4 (PB10/11), TIM3 CH3-4 (PB0/PB1). Timer groups share protocol and rate |
| UARTs | USART1 GPS1, USART2 GPS2/TEL, USART3 TEL3, UART4 companion ("Upper computer", TEL1), UART5 RC (SBUS, with XOR inverter U19 and a 0R option), UART7 ESC telemetry, UART8 debug/aux, UART6 no hardware connection |
| Other | I2C4 + SPI3 expansion pads, USB-C FS device with VBUS detect (PD0), SWD, 3 status LEDs, 3 AUX GPIO, ADC battery V (PC4) and battery I (PC5, external sensor input) |
| Not present | **CAN, buzzer output, second barometer, dedicated compass connector** (I2C4 header only), current sensor |
| Power | 2S-6S input, P-MOSFET reverse-polarity stage (Q1 AP40P05), SMF30CA TVS (D3), two MP9943GQ-Z buck converters (U1, U4), two RT9013-33GB 3.3 V LDOs (U2, U3, "500 mA", Core and Periph rails). Schematic notes: 5 V 3 A rail, 9 V/10 V/12 V adjustable "CAM" rail 3 A (resistor-set), Type-C power path |
| Mounting | 4 holes, vendor lists 20 x 20 mm pattern |

Pin-level connector pinouts (J2-J12) were **not** extracted: that needs a netlist export. Marked as outstanding.

## 3. PX4 status of this design

- The archive contains **no PX4 board files**.
- MicoAir's product page says NxtPX4v2 is officially supported by PX4 and ArduPilot with target `hkust_nxt-dual`, and gives a PX4 UART mapping (TELEM1 UART2, TELEM2 UART4, TELEM3 UART7, GPS1 UART1, GPS2 UART3, RC UART5, SERIAL4 UART8). **This is a vendor claim. I have not yet verified the target in the PX4-Autopilot repository or its release status.** Stage 2 task.
- Because the target name implies the same board as this repo, the PX4 pin map must be compared against this schematic before anything is reused.

## 4. Licence

- `LICENSE`: **BSD 3-Clause, Copyright (c) 2023 Peize-Liu.**
- Obligations if any design data is reused: keep the copyright notice and licence text in redistributed source and in documentation for binary/manufactured distributions; do not use the copyright holder's or contributors' names to endorse a derived product.
- Open items (not legal advice, to be checked before product release):
  - STEP models and some footprints appear to be vendor/third-party downloads (e.g. CSP-USC16, ICM-42688-P); their individual terms are not stated in the repo.
  - Footprint library contains institutional/personal logos (HKU, HILAB, HKUST-style marks, "my_signature", NxtLOGO). Do not carry these into ROXX.

## 5. Useful, modify, replace

| Area | Verdict | Reason |
|---|---|---|
| STM32H743 + dual-BMI088 + SPL06 sensor architecture | **Reuse as concept** | Proven combination; independent SPI buses; drivers exist in PX4 (bmi088, spl06). Confirm in PX4 source |
| Pin allocation (xlsx) | **Reuse as starting point, reconcile** | Good structure (DRDY on EXTI, timer-grouped PWM). The xlsx and `.ioc` disagree in places (e.g. PC2, PC3, PB3, PB4, PD14 appear in the xlsx but not in my filtered `.ioc` extract). Schematic is the authority and must be checked |
| Companion link (UART4) | **Keep concept** | Matches your Pi 5 UART/MAVLink requirement. Needs DMA/flow-control check and 3.3 V level documentation |
| 4-layer stackup, net classes | **Modify** | 0.1 mm track/space and 0.25/0.15 mm vias need a fab capability check and are tight for a first product spin. Power-heavy net classes (0.8 mm for 24 V) are thin for ESC-level currents |
| Power tree | **Replace** | 5 V 3 A shared rail cannot be taken as adequate for a Raspberry Pi 5 (to be verified against Raspberry Pi documentation). A separate, engineered Pi supply is a fixed ROXX requirement. The 9-12 V camera rail is unnecessary for OAK-D Lite (USB-powered) |
| Connectors (SH 1.0 mm, 6-pin etc.) | **Review** | Tiny and fragile for a product; current ratings must be checked against GNSS and Pi loads |
| Missing features | **Add** | Buzzer, CAN (if justified), second barometer decision, hardware watchdog/reset review, current sensing path |
| Libraries and logos | **Clean up** | Remove unrelated branding; verify third-party model licences |
| Documentation | **Replace** | README is empty; no firmware, BOM or MPNs. Schematic values carry package/voltage but few manufacturer part numbers |

## 6. Limitations of this audit

1. No ERC or DRC executed; no KiCad GUI or CLI available here.
2. No netlist, so connector pinouts and net connectivity are not verified.
3. Component ratings and datasheets not yet cross-checked (Stage 2).
4. Schematic (2023-03) and PCB (2023-12) title blocks differ; schematic/PCB consistency is **not verified**.
5. The vendor-reported PX4 support has not been confirmed in the PX4 repository.
6. Your concept image shows the **original NxtPX4 V2 board** plus a custom HAT, which differs from a new ROXX flight-controller PCB. See open question in the README.
