# Change log

- 2026-10-18: Created project directory. Extracted `Nxt-FC-Hardware-NxtDual.zip` to a read-only reference copy (SHA-256 41fca550...f9f8a2). No original files changed.
- 2026-10-18: Wrote hardware_audit.md (Stage 1). Findings: STM32H743 + 2x BMI088 + SPL06, BSD-3-Clause, no firmware in repo, power tree unsuitable for Pi 5 without verification, ERC/DRC not run.
