# Increment 2 — MCU pin-freeze / AF / DMA / EXTI review (pre-schematic gate)

Status: **review document, 2026-10-19. Feeds `gen_mcu_sch.py` (MCU_Core sheet). No schematic output yet unless stated. AF codes marked "verify DS12110" must be confirmed against the STM32H743 datasheet alternate-function table before layout.**

MCU: **STM32H743VIT6** (LQFP100, 2 MB flash) chosen for Rev A instead of the reference board's STM32H743VIH6 (TFBGA100): same die/pin-signal map, hand-reworkable package for a UAV FC prototype. Ball-vs-lead mapping is 1:1 by signal name via `pin_allocation.csv`. **Open item: confirm package decision with user before layout** (reference/PX4 socket compatibility favours BGA; prototyping favours LQFP).

HSE: 16 MHz (reference design crystal value, verified in NxtPX4.kicad_sch). LSE: DNP (no RTC battery in Rev A; VBAT tied to 3.3 V).

## 1 Peripheral → pin → AF cross-check (vs pin_allocation.csv)

| Function | Pins | AF | Check |
|---|---|---|---|
| ESC1-4 (D-02) MOTOR1-4 | PE9/PE11/PE13/PE14 = TIM1_CH1-4 | AF1 | OK; complementary CHxN and BKIN unused; TIM1 on PE forced because PA8-11 consumed by GNSS USART1 + USB |
| Buzzer | PD14 = TIM4_CH3 | AF2 | OK (PD12/13/15 = CH1/2/4 kept free: PD12/13 = I2C4, PD15 = LED) |
| RC (D-03) | PB12/PB13 = UART5_RX/TX | AF8 (verify DS12110) | OK; SBUS/IBUS inversion per interface_spec §4 |
| Companion Pi | PB8/PB9 = UART4_RX/TX | AF8 (verify) | OK |
| GNSS | PA9/PA10 = USART1_TX/RX | AF7 | OK; PPS = PA8 GPIO EXTI8 (not timer-capture in Rev A) |
| TELEM1 | PD5/PD6 = USART2_TX/RX | AF7 | OK |
| TELEM2 (reserve) | PD8/PD9 = USART3_TX/RX | AF7 | OK |
| Console | PC6/PC7 = USART6_TX/RX | AF7 | OK |
| ESC telemetry (reserve) | PE7/PE8 = UART7_RX/TX | AF7 (verify) | OK |
| IMU1 SPI1 | PA5/PA6/PA7 = SCK/MISO/MOSI | AF5 | OK; CS/DRDY = GPIO (PA2/PA3/PA0/PA1) |
| IMU2 SPI4 | PE2/PE5/PE6 = SCK/MISO/MOSI | AF5 | OK — **SPI4_NSS pin PE4 deliberately NOT used** (PE4 = IMU2 ADRDY GPIO); CS = PC0 GPIO. No clash with TIM1 (PE9/11/13/14) |
| Baro I2C1 | PB6/PB7 = SCL/SDA | AF4 | OK |
| Ext I2C4 (reserve) | PD12/PD13 | AF4 | OK |
| CAN (reserve) | PD0/PD1 = FDCAN1_RX/TX | AF9 | OK |
| SDIO | PC8-12, PD2 = SDMMC1 | AF12 (verify) | OK; SDMMC uses internal IDMA, no DMA stream needed |
| USB FS | PA11/PA12 | AF10 | OK; VBUS sense PD7 via protected divider |
| SWD | PA13/PA14 (+PB3 SWO TP) | AF0 | OK |

No AF conflicts found. Two pins carry dual roles only where intended (PB3 = SWO test point, else GPIO-reserved).

## 2 DMA plan (H743 DMA1/DMA2; BDMA unused in Rev A)

| Stream | Request | Direction | Note |
|---|---|---|---|
| DMA1_S0 | USART1_RX (GNSS) | mem-periph | |
| DMA1_S1 | USART2_RX (TELEM1) | mem-periph | |
| DMA1_S2 | USART2_TX | periph-mem | |
| DMA1_S3 | USART3_RX (TELEM2) | mem-periph | reserve |
| DMA1_S4 | UART4_RX (companion) | mem-periph | |
| DMA1_S5 | UART4_TX | periph-mem | |
| DMA2_S0 | UART5_RX (RC) | mem-periph | IDLE-line DMA; lowest-latency path, circular |
| DMA2_S1 | UART7_RX (ESC telem) | mem-periph | reserve |
| DMA2_S2/S3 | SPI1_RX/TX (IMU1) | both | |
| DMA2_S4/S5 | SPI4_RX/TX (IMU2) | both | |
| — | SDMMC1 | internal IDMA | |
| — | USB_OTG_FS | dedicated FIFO | |
| — | TIM1 (DShot) | none | waveforms built in timer registers, no DMA |

No stream double-booked. DMA1_S6/7, DMA2_S6/7 free.

## 3 EXTI plan

| Line | Pin | Source |
|---|---|---|
| EXTI0 | PA0 | IMU1_ADRDY |
| EXTI1 | PA1 | IMU1_GDRDY |
| EXTI3 | PE3 | IMU2_GDRDY |
| EXTI4 | PE4 | IMU2_ADRDY |
| EXTI8 | PA8 | GNSS PPS |
| EXTI9 | PD4? no — IMU1_LDO_EN is output | — |

Port-sharing audit: EXTI0 (PA0) vs PC0/PB0 free ✓; EXTI1 (PA1) vs PB1/PC1 free ✓; EXTI3 (PE3) vs PB3(SWO, non-EXTI use) ✓; EXTI4 (PE4) vs PA4 free ✓; EXTI8 (PA8) vs PB8 (UART4_RX, non-EXTI) ✓. No shared-line contention.

## 4 Reset-safety of ESC outputs (D-02 contract)

- Reset state of PE9/11/13/14 = input floating ⇒ each ESC line gets **33 Ω series + 100 kΩ pull-down** so lines sit Low from battery-insert until firmware configures TIM1 (DShot idle = Low; PWM 1000 µs is generated only after arming).
- Firmware contract: TIM1 clock enabled, channels configured, **MOE (main output enable) held 0** until RC-armed; BDTR.OSSR=0 so outputs stay inactive during fault.
- Same treatment (series 33 Ω, no PD) on UART TX lines to companion/GNSS to avoid boot-garbage injection: **open item — decide per interface in increment 2b**.

## 5 Power/reset/boot hardware (sheet MCU_Core v1 scope)

- VDD×4 + VSS×4: 100 nF X7R 6.3 V per pair (0402) + one 4.7 µF bulk on the pair nearest the package.
- VDDA/VSSA: 100 nF + 1 µF; VREF+ tied to VDDA through ferrite bead (MPN TBD, BLM15-class) + 100 nF + 1 µF; analog unused in Rev A except ADC bat sense → keep filtered anyway.
- VCAP1/VCAP2: 2.2 µF X7R 6.3 V each (value **verify DS12110**, some H7 errata recommend 4.7 µF on specific revs).
- BOOT0: 10 kΩ pull-down + recovery pad (populated 0 Ω option to force bootloader).
- NRST: 10 kΩ pull-up + 100 nF + wire to SWD connector pin + external supervisor **open item** (Rev A may rely on internal POR + SWD nRST; decide with bench risk review).
- SWD: 6-pin 1.25 mm connector (SWDIO/SWCLK/SWO-opt/NRST/3V3/GND).
- HSE: 16 MHz crystal, 2× load caps per chosen MPN (CL computation pending MPN pick; placeholder 2× 12 pF flagged).
- Status LEDs ×3 (active-low per pin table) with 1 kΩ series.

## 6 Open items carried forward

1. LQFP100 vs TFBGA100 package decision (user).
2. AF codes marked "verify DS12110" (UART4/5/8 = AF8, SDMMC = AF12, UART7 = AF7).
3. VCAP value per errata.
4. NRST supervisor yes/no.
5. HSE crystal MPN + load caps.
6. Per-interface series-R/pull-down policy for boot-garbage protection (increment 2b).
