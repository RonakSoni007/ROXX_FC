#!/usr/bin/env python3
"""ROXX FC Rev A - power subsystem schematic generator (KiCad 9).
Emits roxx_power.kicad_sym + roxx_fc.kicad_sch.
Connectivity: rail power symbols, net labels on local nodes, coincident pins
for series chains, one explicit wire (battery -> PMOS drain), PWR_FLAGs on
undriven power nets (same technique as imported reference design).
Pin specs are keyed by PIN NAME (polarity-safe).
"""
import uuid, re, os, math

HERE = os.path.dirname(os.path.abspath(__file__))
KSY = "/usr/share/kicad/symbols"
U = lambda: str(uuid.uuid4())

def extract(libfile, name):
    txt = open(os.path.join(KSY, libfile), encoding="utf-8").read().replace("\r", "")
    out, depth, started = [], 0, False
    for ln in txt.split("\n"):
        if not started:
            if re.match(r'^\t\(symbol "%s"(\s|$)' % re.escape(name), ln):
                started = True
            else:
                continue
        out.append(ln)
        depth += ln.count("(") - ln.count(")")
        if depth <= 0:
            break
    if not out:
        raise SystemExit("symbol not found: %s in %s" % (name, libfile))
    return "\n".join(out)

BUILTIN = [("Device.kicad_sym", "C_Small"), ("Device.kicad_sym", "R_Small"),
           ("Device.kicad_sym", "L_Small"), ("Device.kicad_sym", "D_Zener"), ("Device.kicad_sym", "D_Schottky"),
           ("Device.kicad_sym", "Q_PMOS"), ("Connector.kicad_sym", "TestPoint"),
           ("Connector_Generic.kicad_sym", "Conn_01x02"),
           ("power.kicad_sym", "GND"), ("power.kicad_sym", "PWR_FLAG")]

SYMPINS = {}
LIB_BLOCKS = []
for libfile, nm in BUILTIN:
    blk = extract(libfile, nm)
    lib = libfile.split(".")[0]
    blk = blk.replace('\t(symbol "%s"' % nm, '\t(symbol "%s:%s"' % (lib, nm), 1)
    LIB_BLOCKS.append(blk)
    pins = {}
    for m in re.finditer(r'\(pin\s+\w+\s+\w+\s*\(at\s+([\-\d.]+)\s+([\-\d.]+)\s+(\d+)\)\s*\(length\s+([\d.]+)\)\s*\(name\s+"([^"]*)".*?\(number\s+"([^"]*)"', blk, re.S):
        x, y, rot, _l, pname, num = m.groups()
        pins[pname] = (float(x), float(y), int(rot))
        pins[num] = (float(x), float(y), int(rot))
    SYMPINS[lib + ":" + nm] = pins

def pin(num, name, x, y, rot, etype):
    return ('\t\t\t(pin %s line (at %s %s %d) (length 2.54)\n'
            '\t\t\t\t(name "%s" (effects (font (size 1.27 1.27))))\n'
            '\t\t\t\t(number "%s" (effects (font (size 1.27 1.27)))))\n'
            % (etype, x, y, rot, name, num))

def sym_block(name, refpref, rect, pins):
    s = ('\t(symbol "%s"\n\t\t(in_bom yes) (on_board yes)\n'
         '\t\t(property "Reference" "%s" (at 0 %s 0)\n\t\t\t(effects (font (size 1.27 1.27))))\n'
         '\t\t(property "Value" "%s" (at 0 %s 0)\n\t\t\t(effects (font (size 1.27 1.27))))\n'
         '\t\t(property "Footprint" "" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
         '\t\t(property "Datasheet" "" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
         '\t\t(symbol "%s_0_1"\n'
         '\t\t\t(rectangle (start %s %s) (end %s %s)\n'
         '\t\t\t\t(stroke (width 0.254) (type solid)) (fill (type background)))\n\t\t)\n'
         '\t\t(symbol "%s_1_1"\n' % (name, refpref, rect[3] + 2.54, name, rect[1] - 2.54,
                                     name, rect[0], rect[3], rect[2], rect[1], name))
    s += "".join(pins) + "\t\t)\n\t)\n"
    return s

def power_sym(name):
    return ('\t(symbol "%s"\n\t\t(power) (pin_numbers (hide yes)) (pin_names (hide yes))\n'
            '\t\t(in_bom yes) (on_board yes)\n'
            '\t\t(property "Reference" "#PWR" (at 0 -3.81 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
            '\t\t(property "Value" "%s" (at 0 3.81 0)\n\t\t\t(effects (font (size 1.27 1.27))))\n'
            '\t\t(property "Footprint" "" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
            '\t\t(property "Datasheet" "" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
            '\t\t(symbol "%s_0_1"\n'
            '\t\t\t(polyline (pts (xy -0.762 1.27) (xy 0 0) (xy 0.762 1.27))\n'
            '\t\t\t\t(stroke (width 0.254) (type solid)) (fill (type none)))\n'
            '\t\t\t(pin power_in line (at 0 0 90) (length 0)\n'
            '\t\t\t\t(name "%s" (effects (font (size 1.27 1.27))))\n'
            '\t\t\t\t(number "1" (effects (font (size 1.27 1.27)))))\n\t\t)\n\t)\n'
            % (name, name, name, name))

tps54160 = sym_block("TPS54160ADGQ", "U", (-7.62, -12.7, 7.62, 10.16), [
    pin("2", "VIN", -7.62, 7.62, 0, "power_in"), pin("3", "EN", -7.62, 5.08, 0, "input"),
    pin("4", "SS/TR", -7.62, 2.54, 0, "input"), pin("5", "RT/CLK", -7.62, 0, 0, "input"),
    pin("7", "VSENSE", -7.62, -2.54, 0, "input"), pin("8", "COMP", -7.62, -5.08, 0, "passive"),
    pin("1", "BOOT", 7.62, 7.62, 180, "passive"), pin("10", "PH", 7.62, 5.08, 180, "output"),
    pin("6", "PWRGD", 7.62, -5.08, 180, "open_collector"),
    pin("9", "GND", -1.27, -12.7, 270, "power_in"), pin("11", "PAD", 1.27, -12.7, 270, "passive")])
ap2112 = sym_block("AP2112K-3.3", "U", (-5.08, -5.08, 5.08, 5.08), [
    pin("1", "VIN", -5.08, 2.54, 0, "power_in"), pin("3", "EN", -5.08, 0, 0, "input"),
    pin("5", "VOUT", 5.08, 2.54, 180, "power_out"),
    pin("2", "GND", 0, -5.08, 270, "power_in")])
tps7a20 = sym_block("TPS7A2033", "U", (-5.08, -5.08, 5.08, 5.08), [
    pin("1", "IN", -5.08, 2.54, 0, "power_in"), pin("3", "EN", -5.08, 0, 0, "input"),
    pin("5", "OUT", 5.08, 2.54, 180, "power_out"),
    pin("2", "GND", 0, -5.08, 270, "power_in")])
def sym_block_g(name, refpref, rect, pins, graphics):
    s = ('\t(symbol "%s"\n\t\t(in_bom yes) (on_board yes)\n'
         '\t\t(property "Reference" "%s" (at 0 %s 0)\n\t\t\t(effects (font (size 1.27 1.27))))\n'
         '\t\t(property "Value" "%s" (at 0 %s 0)\n\t\t\t(effects (font (size 1.27 1.27))))\n'
         '\t\t(property "Footprint" "" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
         '\t\t(property "Datasheet" "" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
         '\t\t(symbol "%s_0_1"\n%s\t\t)\n'
         '\t\t(symbol "%s_1_1"\n' % (name, refpref, rect[3] + 2.54, name, rect[1] - 2.54, name, graphics, name))
    s += "".join(pins) + "\t\t)\n\t)\n"
    return s

TVS_GRAPHICS = ('\t\t\t(polyline (pts (xy -0.762 -0.762) (xy 0.762 -0.762) (xy 0 0.762) (xy -0.762 -0.762))\n'
                '\t\t\t\t(stroke (width 0.254) (type solid)) (fill (type none)))\n'
                '\t\t\t(polyline (pts (xy -0.762 0.762) (xy 0.762 0.762))\n'
                '\t\t\t\t(stroke (width 0.254) (type solid)) (fill (type none)))\n'
                '\t\t\t(polyline (pts (xy -0.762 0.762) (xy -1.143 0.381))\n'
                '\t\t\t\t(stroke (width 0.254) (type solid)) (fill (type none)))\n'
                '\t\t\t(polyline (pts (xy 0.762 0.762) (xy 1.143 1.143))\n'
                '\t\t\t\t(stroke (width 0.254) (type solid)) (fill (type none)))\n')
tvs_uni = sym_block_g("TVS_UNI", "D", (-1.27, -1.27, 1.27, 1.27), [
    pin("1", "K", 0, 1.27, 270, "passive"), pin("2", "A", 0, -1.27, 90, "passive")], TVS_GRAPHICS)
RAILS = ["VBAT_IN", "VBUS_FC", "SYS_5V", "CORE_3V3", "PERIPH_3V3", "IMU1_3V3", "IMU2_3V3", "BARO_3V3"]
SYMPINS["ROXX_PWR:TPS54160ADGQ"] = {"VIN": (-7.62, 7.62, 0), "EN": (-7.62, 5.08, 0), "SS/TR": (-7.62, 2.54, 0),
    "RT/CLK": (-7.62, 0, 0), "VSENSE": (-7.62, -2.54, 0), "COMP": (-7.62, -5.08, 0),
    "BOOT": (7.62, 7.62, 0), "PH": (7.62, 5.08, 0), "PWRGD": (7.62, -5.08, 0),
    "GND": (-1.27, -12.7, 0), "PAD": (1.27, -12.7, 0)}
SYMPINS["ROXX_PWR:AP2112K-3.3"] = {"VIN": (-5.08, 2.54, 0), "EN": (-5.08, 0, 0),
    "VOUT": (5.08, 2.54, 0), "GND": (0, -5.08, 0)}
SYMPINS["ROXX_PWR:TPS7A2033"] = {"IN": (-5.08, 2.54, 0), "EN": (-5.08, 0, 0),
    "OUT": (5.08, 2.54, 0), "GND": (0, -5.08, 0)}
SYMPINS["ROXX_PWR:TVS_UNI"] = {"K": (0, 1.27, 0), "A": (0, -1.27, 0)}
for r in RAILS:
    SYMPINS["ROXX_PWR:" + r] = {"1": (0, 0, 0)}
SYMPINS["power:GND"] = {"1": (0, 0, 0)}
SYMPINS["power:PWR_FLAG"] = {"1": (0, 0, 0)}

LIB_SYM = '(kicad_symbol_lib\n\t(version 20241209)\n\t(generator "kicad_symbol_editor")\n\t(generator_version "9.0.2")\n'
LIB_SYM += tps54160 + ap2112 + tps7a20 + tvs_uni + "".join(power_sym(r) for r in RAILS) + ")\n"
open(os.path.join(HERE, "roxx_power.kicad_sym"), "w").write(LIB_SYM)

def conn(lib, at, rot, pname):
    try:
        px, py, _pr = SYMPINS[lib][pname]
    except KeyError:
        raise SystemExit("MISSING PIN %s in %s ; have %s" % (pname, lib, list(SYMPINS.get(lib,{}).keys())))
    a = math.radians(rot)
    return (round(at[0] + px * math.cos(a) + py * math.sin(a), 3),
            round(at[1] + px * math.sin(a) - py * math.cos(a), 3))

C0402 = "Capacitor_SMD:C_0402_1005Metric"; C0603 = "Capacitor_SMD:C_0603_1608Metric"
C0805 = "Capacitor_SMD:C_0805_2012Metric"; C1206 = "Capacitor_SMD:C_1206_3216Metric"
R0402 = "Resistor_SMD:R_0402_1005Metric"; SOT23 = "Package_TO_SOT_SMD:SOT-23"
SOT235 = "Package_TO_SOT_SMD:SOT-23-5"; SMB = "Diode_SMD:D_SMB"; SMA = "Diode_SMD:D_SMA"
MSOP = "Package_SO:MSOP-10-1EP_3x3mm_P0.5mm_EP1.73x1.98mm"; TPFP = "TestPoint:TestPoint_Pad_D1.5mm"
LFP = "roxx_fc:L_TDK_SPM6530T"
Y50 = "CC0402KRX7R9BB104"; Y16 = "CC0402KRX7R7BB104"; Y10 = "CC0402KRX7R6BB104"
CAP1050 = "CL31A106KAHNNNE"; CAP2210 = "GRM21BR71A226ME51L"; CAP4716 = "GRM188R71C475KE15D"
def rgc(s):
    m = re.match(r"([\d.]+)\s*[kK]$", str(s))
    if m:
        num = m.group(1)
        if "." in num:
            a, b = num.split(".")
            b = b.rstrip("0")
            num = a + "K" + b if b else a + "K"
        else:
            num = num + "K"
        return num
    return str(s)
RG = lambda v: "RC0402FR-07%sL" % rgc(v)

P = []
def add(ref, lib, val, fp, mpn, at, rot, pins, ds="", refat=None, valat=None, hideval=False):
    P.append(dict(ref=ref, lib=lib, val=val, fp=fp, mpn=mpn, at=at, rot=rot, pins=pins, ds=ds,
                  refat=refat, valat=valat, hideval=hideval))

# ================= input protection =================
add("J1", "Connector_Generic:Conn_01x02", "BAT_IN 4S-6S", "Connector_JST:JST_XH_B2B-XH-A_1x02_P2.50mm_Vertical",
    "B2B-XH-A", (17.78, 35.56), 0, {"1": ("W", 33.02, 35.56), "2": ("G",)})
add("Q1", "Device:Q_PMOS", "SQ2309ES -60V P-ch", SOT23, "SQ2309ES-T1-GE3", (30.48, 30.48), 0,
    {"G": ("L", "GATE_Q1"), "S": ("L", "VBAT_IN"), "D": ("L", "VBUS_FC")},
    "https://www.vishay.com/docs/66718/sq2309es.pdf")
add("R1", "Device:R_Small", "100k 1%", R0402, RG("100K"), (22.86, 31.75), 0,
    {"1": ("L", "GATE_Q1"), "2": ("G",)})
add("D1", "Device:D_Zener", "BZX84-C12", SOT23, "BZX84-C12,215", (27.94, 26.67), 0,
    {"K": ("P", "VBAT_IN"), "A": ("L", "GATE_Q1")}, valat=(22.86, 24.13))
add("C1", "Device:C_Small", "100nF 50V X7R", C0402, Y50, (20.32, 31.75), 0,
    {"1": ("P", "VBAT_IN"), "2": ("L", "GATE_Q1")})
add("D2", "ROXX_PWR:TVS_UNI", "SMBJ30A", SMB, "SMBJ30A", (35.56, 29.21), 0,
    {"K": ("P", "VBUS_FC"), "A": ("G",)}, "https://www.littelfuse.com/products/tvs-diodes")
for ref, x in [("C2", 40.64), ("C3", 45.72), ("C4", 50.8)]:
    add(ref, "Device:C_Small", "10uF 50V X7R", C1206, CAP1050, (x, 29.21), 0,
        {"1": ("P", "VBUS_FC"), "2": ("G",)})
add("C5", "Device:C_Small", "100nF 50V X7R", C0402, Y50, (55.88, 29.21), 0,
    {"1": ("P", "VBUS_FC"), "2": ("G",)})
add("TP1", "Connector:TestPoint", "VBAT", TPFP, "", (40.64, 35.56), 0, {"1": ("L", "VBAT_IN")})
add("TP2", "Connector:TestPoint", "VBUS", TPFP, "", (60.96, 26.67), 0, {"1": ("L", "VBUS_FC")})
add("F1", "power:PWR_FLAG", "PWR_FLAG", "", "", (30.48, 35.56), 0, {"1": ("L", "VBAT_IN")})
add("F2", "power:PWR_FLAG", "PWR_FLAG", "", "", (63.5, 26.67), 0, {"1": ("L", "VBUS_FC")})
add("F3", "power:PWR_FLAG", "PWR_FLAG", "", "", (58.42, 40.64), 0, {"1": ("G",)})

def buck(u, n, ox, rail, vals):
    add("U" + u, "ROXX_PWR:TPS54160ADGQ", "TPS54160ADGQR", MSOP, "TPS54160ADGQR", (ox, 40.64), 0, {
        "VIN": ("L", "VBUS_FC"), "EN": ("L", "EN_" + n), "SS/TR": ("L", "SS_" + n),
        "RT/CLK": ("L", "RT_" + n), "VSENSE": ("L", "FB_" + n), "COMP": ("L", "COMP_" + n),
        "BOOT": ("L", "BOOT_" + n), "PH": ("L", "PH_" + n), "PWRGD": ("L", "PWRGD_" + n),
        "GND": ("G",), "PAD": ("G",)}, "https://www.ti.com/lit/ds/symlink/tps54160.pdf")
    v = vals
    # flip semantics: pin1 (py=+2.54) = TOP of screen, pin2 = BOTTOM
    add("C" + v["boot"], "Device:C_Small", "100nF 16V X7R", C0402, Y16, (ox + 12.7, 43.18), 0,
        {"1": ("L", "BOOT_" + n), "2": ("L", "PH_" + n)})
    add("R" + v["rt"], "Device:R_Small", "237k 1% (500kHz)", R0402, RG("237k"), (ox - 7.62, 55.88), 0,
        {"1": ("L", "RT_" + n), "2": ("G",)})
    add("C" + v["ss"], "Device:C_Small", "100nF 16V X7R", C0402, Y16, (ox - 15.24, 50.8), 0,
        {"1": ("L", "SS_" + n), "2": ("G",)})
    add("R" + v["crs"], "Device:R_Small", v["crsv"] + " 1%", R0402, RG(v["crsv"]),
        (ox - 20.32, 38.1), 0, {"1": ("L", "COMP_" + n), "2": ("L", "Z_" + n)})
    add("C" + v["ccs"], "Device:C_Small", v["ccsv"], C0402, v["ccsm"], (ox - 20.32, 43.18), 0,
        {"1": (), "2": ("G",)})
    add("C" + v["ccp"], "Device:C_Small", v["ccpv"], C0402, v["ccpm"], (ox - 17.78, 45.72), 0,
        {"1": ("L", "COMP_" + n), "2": ("G",)})
    add("R" + v["fb1"], "Device:R_Small", v["fb1v"] + " 1%", R0402, RG(v["fb1v"]), (ox + 20.32, 44.45), 0,
        {"1": ("P", rail), "2": ("L", "FB_" + n)})
    add("R" + v["fb2"], "Device:R_Small", v["fb2v"] + " 1%", R0402, RG(v["fb2v"]), (ox + 20.32, 49.53), 0,
        {"1": (), "2": ("G",)})
    add("R" + v["en1"], "Device:R_Small", v["en1v"] + " 1%", R0402, RG(v["en1v"]), (ox - 12.7, 33.02), 0,
        {"1": ("P", "VBUS_FC"), "2": ("L", "EN_" + n)})
    add("R" + v["en2"], "Device:R_Small", v["en2v"] + " 1%", R0402, RG(v["en2v"]), (ox - 12.7, 38.1), 0,
        {"1": (), "2": ("G",)})
    add("D" + v["dz"], "Device:D_Zener", "BZX84-C4V7 EN clamp", SOT23, "BZX84-C4V7,215", (ox - 25.4, v["dzy"]), 0,
        {"K": ("L", "EN_" + n), "A": ("G",)}, hideval=True)
    add("L" + v["l"], "Device:L_Small", "22uH Isat2.3A", LFP, "SPM6530T-220M-HZ", (ox + 15.24, 41.91), 0,
        {"1": ("L", "PH_" + n), "2": ("P", rail)},
        "https://product.tdk.com/en/search/inductor/inductor/smd/info?part_no=SPM6530T-220M-HZ")
    add("D" + v["dc"], "Device:D_Schottky", "B360-13-F", SMA, "B360-13-F", (ox + 13.97, 50.8), 0,
        {"K": ("L", "PH_" + n), "A": ("G",)})
    for k, (ref, x) in enumerate(zip(v["cout"], [ox + 22.86, ox + 25.4, ox + 27.94])):
        add(ref, "Device:C_Small", "22uF 10V X7R" if k < 2 else "100nF 10V X7R",
            C0805 if k < 2 else C0402, CAP2210 if k < 2 else Y10, (x, 38.1), 0,
            {"1": ("P", rail), "2": ("G",)})
    add("R" + v["rp"], "Device:R_Small", "100k 1%", R0402, RG("100K"), (ox + 12.7, 33.02), 0,
        {"1": ("P", rail), "2": ("L", "PWRGD_" + n)})
    add("TP" + v["tp"], "Connector:TestPoint", "PWRGD", TPFP, "", (ox + 15.24, 33.02), 0,
        {"1": ("L", "PWRGD_" + n)})

buck("1", "5V", 71.12, "SYS_5V", dict(boot="6", rt="2", ss="10", crs="3", crsv="100k", ccs="11",
     ccsv="1.8nF 16V C0G", ccsm="CC0402JRNPO9BN182", ccp="12", ccpv="6.8pF 50V C0G",
     ccpm="CC0402JRNPO9BN6R8", fb1="4", fb1v="105k", fb2="5", fb2v="20.0k", en1="6", en1v="511k",
     en2="7", en2v="62.6k", dz="4", dc="3", l="1", dzy=34.29, cout=["C7", "C8", "C9"], rp="8", tp="3"))
buck("2", "3V3", 124.46, "CORE_3V3", dict(boot="13", rt="9", ss="14", crs="10", crsv="66.5k", ccs="15",
     ccsv="3.3nF 16V C0G", ccsm="CC0402JRNPO9BN332", ccp="16", ccpv="10pF 50V C0G",
     ccpm="CC0402JRNPO9BN100", fb1="11", fb1v="62.6k", fb2="12", fb2v="20.0k", en1="13", en1v="511k",
     en2="14", en2v="62.6k", dz="6", dc="5", l="2", dzy=26.67, cout=["C17", "C18", "C19"], rp="15", tp="4"))
add("F4", "power:PWR_FLAG", "PWR_FLAG", "", "", (96.52, 33.02), 0, {"1": ("P", "SYS_5V")})
add("F5", "power:PWR_FLAG", "PWR_FLAG", "", "", (149.86, 33.02), 0, {"1": ("P", "CORE_3V3")})
add("TP11", "Connector:TestPoint", "IMU1 PWR EN", TPFP, "", (91.44, 83.82), 0, {"1": ("L", "IMU1_PWR_EN")})
add("TP12", "Connector:TestPoint", "IMU2 PWR EN", TPFP, "", (121.92, 83.82), 0, {"1": ("L", "IMU2_PWR_EN")})
add("TP13", "Connector:TestPoint", "BARO PWR EN", TPFP, "", (152.4, 83.82), 0, {"1": ("L", "BARO_PWR_EN")})
add("TP5", "Connector:TestPoint", "SYS_5V", TPFP, "", (97.79, 45.72), 0, {"1": ("P", "SYS_5V")})
add("TP6", "Connector:TestPoint", "CORE_3V3", TPFP, "", (146.05, 50.8), 0, {"1": ("P", "CORE_3V3")})

# ================= LDO rails =================
add("U3", "ROXX_PWR:AP2112K-3.3", "AP2112K-3.3TRG1", SOT235, "AP2112K-3.3TRG1", (60.96, 81.28), 0,
    {"VIN": ("P", "SYS_5V"), "EN": ("P", "SYS_5V"), "VOUT": ("P", "PERIPH_3V3"), "GND": ("G",)},
    "https://www.diodes.com/assets/Datasheets/AP2112.pdf")
add("C20", "Device:C_Small", "4.7uF 16V X7R", C0603, CAP4716, (50.8, 78.74), 0, {"1": ("P", "SYS_5V"), "2": ("G",)})
add("C21", "Device:C_Small", "4.7uF 16V X7R", C0603, CAP4716, (68.58, 78.74), 0, {"1": ("P", "PERIPH_3V3"), "2": ("G",)})
add("C22", "Device:C_Small", "4.7uF 16V X7R", C0603, CAP4716, (76.2, 78.74), 0, {"1": ("P", "PERIPH_3V3"), "2": ("G",)})
add("TP7", "Connector:TestPoint", "PERIPH_3V3", TPFP, "", (78.74, 83.82), 0, {"1": ("P", "PERIPH_3V3")})
for uref, rail, en, cin, cout, tp, x in [
        ("U4", "IMU1_3V3", "IMU1_PWR_EN", "C23", "C24", "TP8", 96.52),
        ("U5", "IMU2_3V3", "IMU2_PWR_EN", "C25", "C26", "TP9", 127.0),
        ("U6", "BARO_3V3", "BARO_PWR_EN", "C27", "C28", "TP10", 157.48)]:
    add(uref, "ROXX_PWR:TPS7A2033", "TPS7A2033PDBVR", SOT235, "TPS7A2033PDBVR", (x, 81.28), 0,
        {"IN": ("P", "SYS_5V"), "EN": ("L", en), "OUT": ("P", rail), "GND": ("G",)},
        "https://www.ti.com/lit/ds/symlink/tps7a20.pdf")
    add(cin, "Device:C_Small", "4.7uF 16V X7R", C0603, CAP4716, (x - 10.16, 78.74), 0, {"1": ("P", "SYS_5V"), "2": ("G",)})
    add(cout, "Device:C_Small", "4.7uF 16V X7R", C0603, CAP4716, (x + 10.16, 78.74), 0, {"1": ("P", rail), "2": ("G",)})
    add(tp, "Connector:TestPoint", rail, TPFP, "", (x + 12.7, 83.82), 0, {"1": ("P", rail)})

# ================= collect connections =================
rails, gnds, wires, labels = [], [], [], []
for p in P:
    for pname, spec in p["pins"].items():
        c = conn(p["lib"], p["at"], p["rot"], pname)
        if not spec:
            continue
        k = spec[0]
        if k == "L":
            labels.append((spec[1], c))
        elif k == "JL":
            labels.append((spec[1], c))
        elif k == "P":
            rails.append((spec[1], c))
        elif k == "G":
            gnds.append(c)
        elif k == "W":
            wires.append((c, (spec[1], spec[2])))
npwr = [0]
def pwref():
    npwr[0] += 1
    return "#PWR%02d" % npwr[0]
for rail, c in rails:
    P.append(dict(ref=pwref(), lib="ROXX_PWR:" + rail, val=rail, fp="", mpn="", at=c, rot=0, pins={}, ds=""))
for c in gnds:
    P.append(dict(ref=pwref(), lib="power:GND", val="GND", fp="", mpn="", at=c, rot=0, pins={}, ds=""))

# ================= emit =================
S = []
S.append('(kicad_sch (version 20250114) (generator "roxx_sch_gen") (generator_version "1.0")')
S.append('  (uuid "%s")' % U())
S.append('  (paper "A3")')
S.append('  (title_block (title "ROXX Flight Controller Rev A - Power Subsystem") (date "2026-10-18") (rev "A0") (company "ROXX") (comment 1 "Stage 4 inc.1: power only. ERC-run. Not routed. Not flight-ready."))')
S.append('  (lib_symbols')
for blk in LIB_BLOCKS:
    S.append("\n".join(("\t" + l) if l else l for l in blk.split("\n")))
for nm in ["TPS54160ADGQ", "AP2112K-3.3", "TPS7A2033", "TVS_UNI"] + RAILS:
    blk = re.search(r'\t\(symbol "%s".*?\n\t\)\n' % re.escape(nm), LIB_SYM, re.S).group(0)
    blk = blk.replace('\t(symbol "%s"' % nm, '\t(symbol "ROXX_PWR:%s"' % nm, 1)
    S.append(blk.rstrip("\n"))
S.append('  )')
for a, b in wires:
    S.append('  (wire (pts (xy %s %s) (xy %s %s)) (stroke (width 0) (type default)) (uuid "%s"))' % (a[0], a[1], b[0], b[1], U()))
for net, c in labels:
    S.append('  (label "%s" (at %s %s 0) (effects (font (size 1.27 1.27)) (justify left bottom)) (uuid "%s"))' % (net, c[0], c[1], U()))
_keep = {}
for p in P:
    if p["ref"].startswith("#PWR") and p["lib"] != "power:PWR_FLAG":
        key = p["val"] if p["lib"] != "power:GND" else "GND"
        hid = False
        for q in _keep.get(key, []):
            if abs(q[0] - p["at"][0]) <= 6.35 and abs(q[1] - p["at"][1]) <= 2.54:
                hid = True; break
        if hid:
            p["valhide"] = True
        else:
            _keep.setdefault(key, []).append(p["at"])
for p in P:
    nobom = p["ref"].startswith("#PWR") or "PWR_FLAG" in p["lib"]
    S.append('  (symbol (lib_id "%s") (at %s %s %d) (unit 1)' % (p["lib"], p["at"][0], p["at"][1], p["rot"]))
    S.append('    (in_bom %s) (on_board yes) (dnp no)' % ("no" if nobom else "yes"))
    S.append('    (uuid "%s")' % U())
    x, y = p["at"]
    lib = p["lib"]; refhide = valhide = False
    refr = valr = 0
    refpos = (x, round(y - 2.0, 2)); valpos = (x, round(y + 2.0, 2))
    if p["ref"].startswith("#PWR"):
        refhide = True
        valpos = (x, round(y - 1.27, 2)) if lib != "power:GND" else (x, round(y + 2.0, 2))
        valhide = p.get("valhide", False)
    elif "PWR_FLAG" in lib:
        refhide = valhide = True
    elif lib in ("Device:R_Small", "Device:C_Small", "Device:L_Small"):
        refpos = (round(x + 0.635, 2), y); valpos = (round(x - 0.635, 2), y)
        refr = valr = 90
        p["smallfont"] = True
    elif lib in ("Device:D_Schottky", "Device:D_Zener"):
        refpos = (x, round(y + 2.54, 2)); valpos = (x, round(y - 2.54, 2))
    elif lib == "ROXX_PWR:TVS_UNI":
        refpos = (round(x - 2.54, 2), round(y - 2.54, 2)); valpos = (round(x - 2.54, 2), round(y + 2.54, 2))
    elif lib == "ROXX_PWR:TPS54160ADGQ":
        refpos = (x, round(y - 15.24, 2)); valpos = (round(x + 5.08, 2), round(y + 15.24, 2))
    elif lib in ("ROXX_PWR:AP2112K-3.3", "ROXX_PWR:TPS7A2033"):
        refpos = (x, round(y - 7.62, 2)); valpos = (x, round(y + 7.62, 2))
    if p.get("refat"): refpos = p["refat"]
    if p.get("valat"): valpos = p["valat"]
    if p.get("hideval"): valhide = True
    hid = lambda h: " (hide yes)" if h else ""
    fs = "1.0 1.0" if p.get("smallfont") else "1.27 1.27"
    S.append('    (property "Reference" "%s" (at %s %s %d)\n      (effects (font (size %s))%s))' % (p["ref"], refpos[0], refpos[1], refr, fs, hid(refhide)))
    S.append('    (property "Value" "%s" (at %s %s %d)\n      (effects (font (size %s))%s))' % (p["val"], valpos[0], valpos[1], valr, fs, hid(valhide)))
    S.append('    (property "Footprint" "%s" (at %s %s 0)\n      (effects (font (size 1.27 1.27)) (hide yes)))' % (p["fp"], p["at"][0], p["at"][1]))
    S.append('    (property "Datasheet" "%s" (at %s %s 0)\n      (effects (font (size 1.27 1.27)) (hide yes)))' % (p["ds"], p["at"][0], p["at"][1]))
    if p["mpn"]:
        S.append('    (property "MPN" "%s" (at %s %s 0)\n      (effects (font (size 1.27 1.27)) (hide yes)))' % (p["mpn"], p["at"][0], p["at"][1]))
    S.append('  )')
# --- incremental: hierarchical sheet for MCU_Core (Stage 4 inc.2) ---
MCU_SHEET_UUID = "00000000-0000-4000-8000-000000000c02"
S.append('  (sheet (at 298.45 203.2) (size 40 20) (fields_autoplaced no)')
S.append('    (stroke (width 0) (type solid))')
S.append('    (fill (color 0 0 0 0.0000))')
S.append('    (uuid %s)' % MCU_SHEET_UUID)
S.append('    (property "Sheet name" "MCU_Core" (at 298.45 201.93 0)\n      (effects (font (size 1.27 1.27)) (justify left bottom)))')
S.append('    (property "Sheet file" "roxx_mcu.kicad_sch" (at 298.45 223.93 0)\n      (effects (font (size 1.27 1.27)) (justify left top)))')
S.append('    (pin "CORE_3V3" input (at 298.45 215.9 180)\n      (effects (font (size 1.27 1.27)))\n      (uuid 00000000-0000-4000-8000-000000000c03))')
S.append('  )')
S.append('  (wire (pts (xy 290.83 215.9) (xy 298.45 215.9))\n    (stroke (width 0) (type solid)))')
S.append('  (label "CORE_3V3" (at 290.83 215.9 0)\n    (effects (font (size 1.27 1.27)) (justify left bottom)))')
S.append('  (sheet_instances (path "/" (page "1")))')
S.append(')')
open(os.path.join(HERE, "roxx_fc.kicad_sch"), "w").write("\n".join(S) + "\n")
print("instances:", len(P), "labels:", len(labels), "wires:", len(wires), "rails:", len(rails), "gnds:", len(gnds))
