#!/usr/bin/env python3
"""ROXX FC Rev A - increment 2: MCU_Core sheet generator (KiCad 9), v2.
Emits roxx_mcu.kicad_sch (child sheet of roxx_fc.kicad_sch).
Pin map source of truth: ../pin_allocation.csv (LQFP100).
Connectivity technique (same as sheet 1): labels at exact pin endpoints,
coincident pins, GND power symbols at endpoints; NO guessed wire geometry.
All coordinates on the 2.54 mm grid.
Scope v1: MCU + decoupling + VDDA/VREF+ filter + VCAP + BOOT0 + NRST +
SWD 6p + HSE 16 MHz + 3 status LEDs. IO pins not yet wired get explicit
no-connect markers (peripherals land in increment 2b).
"""
import csv, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
KSY = "/usr/share/kicad/symbols"
G = 2.54  # grid

CNT = [0]
def hx(seed):
    CNT[0] += 1
    return "%08x-%04x-4000-8000-%012x" % (abs(hash(str(seed))) & 0xffffffff,
                                           CNT[0] & 0xffff,
                                           abs(hash(str(seed) + "z")) & 0xffffffffffff)

def extract(libfile, name):
    txt = open(os.path.join(KSY, libfile), encoding="utf-8").read().replace("\r", "")
    out, depth, started = [], 0, False
    for ln in txt.split("\n"):
        if not started:
            if re.match(r'^\t\(symbol "%s"(\s|$)' % re.escape(name), ln):
                started = True
            else:
                continue
        out.append(ln)
        depth += ln.count("(") - ln.count(")")
        if depth <= 0:
            break
    if not out:
        raise SystemExit("symbol not found: %s in %s" % (name, libfile))
    blk = "\n".join(out)
    return blk.replace('\t(symbol "%s"' % name, '\t(symbol "%s:%s"' % (libfile.split(".")[0], name), 1)

EMB_BLOCKS = {}
for libfile, nm in [("Device.kicad_sym", "C_Small"), ("Device.kicad_sym", "R_Small"),
                    ("Device.kicad_sym", "LED"), ("Device.kicad_sym", "FerriteBead_Small"),
                    ("Device.kicad_sym", "Crystal"),
                    ("Connector_Generic.kicad_sym", "Conn_01x06"),
                    ("Connector.kicad_sym", "TestPoint"),
                    ("power.kicad_sym", "GND"), ("power.kicad_sym", "PWR_FLAG")]:
    lib = libfile.split(".")[0]
    EMB_BLOCKS[lib + ":" + nm] = extract(libfile, nm)

def parse_pins(block):
    """pin number -> endpoint offset (x,y) relative to symbol origin."""
    pins = {}
    for m in re.finditer(r'\(pin\s+\w+\s+\w+\s*\(at\s+([-\d.]+)\s+([-\d.]+)\s+(\d+)\)\s*\(length\s+([\d.]+)\)\s*\(name\s+"([^"]*)".*?\(number\s+"([^"]*)"', block, re.S):
        x, y, rot, _l, _nm, num = m.groups()
        pins[num] = (float(x), float(y))
    return pins

SYMPINS = {k: parse_pins(v) for k, v in EMB_BLOCKS.items()}

# ---------------- MCU symbol from pin_allocation.csv ----------------
rows = list(csv.DictReader(open(os.path.join(HERE, os.pardir, "pin_allocation.csv"))))
PINS = []  # (number, signal, etype)
for r in rows:
    num = r["LQFP100_contact"].strip()
    sig = r["MCU_signal"].strip()
    role = r["ROXX_net_or_role"].strip()
    if role == "power/reset" or sig in ("VDD", "VSS", "VDDA", "VSSA", "VREF+", "VBAT", "VCAP"):
        et = "power_in"
    elif sig in ("NRST", "BOOT0"):
        et = "input"
    elif "OSC_IN" in sig:
        et = "input"
    elif "OSC_OUT" in sig:
        et = "output"
    else:
        et = "bidirectional"
    PINS.append((num, sig.split(" ")[0], et))
assert len(PINS) == 100, len(PINS)

# MCU geometry: left column pins 1..50, right column 51..100, spacing 2.54
MCU_PINS = {}   # number -> endpoint offset from symbol origin
pinlines = []
for i, (num, name, et) in enumerate(PINS):
    if i < 50:
        y = -63.5 + i * G
        pinlines.append('\t\t\t(pin %s line (at -17.78 %s 0) (length 2.54)\n'
                        '\t\t\t\t(name "%s" (effects (font (size 1.27 1.27))))\n'
                        '\t\t\t\t(number "%s" (effects (font (size 1.27 1.27)))))\n' % (et, y, name, num))
        MCU_PINS[num] = (-17.78, y)
    else:
        y = -63.5 + (i - 50) * G
        pinlines.append('\t\t\t(pin %s line (at 17.78 %s 180) (length 2.54)\n'
                        '\t\t\t\t(name "%s" (effects (font (size 1.27 1.27))))\n'
                        '\t\t\t\t(number "%s" (effects (font (size 1.27 1.27)))))\n' % (et, y, name, num))
        MCU_PINS[num] = (17.78, y)
MCU = ('\t(symbol "ROXX_MCU:STM32H743VIT6"\n'
       '\t\t(pin_names (offset 1.016))\n'
       '\t\t(exclude_from_sim no)\n\t\t(in_bom yes) (on_board yes)\n'
       '\t\t(property "Reference" "U" (at 0 -68.58 0)\n\t\t\t(effects (font (size 1.27 1.27))))\n'
       '\t\t(property "Value" "STM32H743VIT6" (at 0 68.58 0)\n\t\t\t(effects (font (size 1.27 1.27))))\n'
       '\t\t(property "Footprint" "Package_QFP:LQFP-100_14x14mm_P0.5mm" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
       '\t\t(property "Datasheet" "DS12110 STM32H743" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
       '\t\t(property "MPN" "STM32H743VIT6" (at 0 0 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
       '\t\t(symbol "STM32H743VIT6_0_1"\n'
       '\t\t\t(rectangle (start -15.24 -66.04) (end 15.24 66.04)\n'
       '\t\t\t\t(stroke (width 0.254) (type solid)) (fill (type background)))\n\t\t)\n'
       '\t\t(symbol "STM32H743VIT6_1_1"\n' + "".join(pinlines) + '\t\t)\n\t)\n')

FPS = {"Device:C_Small": "Capacitor_SMD:C_0402_1005Metric",
       "Device:R_Small": "Resistor_SMD:R_0402_1005Metric",
       "Device:LED": "LED_SMD:LED_0603_1608Metric",
       "Device:FerriteBead_Small": "Inductor_SMD:L_0402_1005Metric",
       "Device:Crystal": "Crystal:Crystal_SMD_3225-4Pin_3.2x2.5mm",
       "Connector_Generic:Conn_01x06": "Connector_JST:JST_SH_SM06B-SRSS-TB_1x06-1MP_P1.00mm_Horizontal",
       "Connector:TestPoint": "TestPoint:TestPoint_Pad_D1.0mm",
       "power:GND": "",
       "ROXX_MCU:STM32H743VIT6": "Package_QFP:LQFP-100_14x14mm_P0.5mm"}

# ---------------- sheet body emission ----------------
BODY = []
NOCONN = []

def rnd(v):
    return round(v + 1e-9, 4)

def fmt(v):
    v = rnd(v)
    return ("%g" % v)

def emit_symbol(ref, libid, val, x, y, mpn="", rot=0):
    s = ('\t(symbol (lib_id "%s") (at %s %s %d) (unit 1)\n'
         '\t\t(in_bom yes) (on_board yes) (dnp no)\n'
         '\t\t(uuid "%s")\n'
         '\t\t(property "Reference" "%s" (at %s %s 0)\n'
         '\t\t\t(effects (font (size 1.27 1.27))))\n'
         '\t\t(property "Value" "%s" (at %s %s 0)\n'
         '\t\t\t(effects (font (size 1.27 1.27))))\n'
         '\t\t(property "Footprint" "%s" (at %s %s 0)\n'
         '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
         '\t\t(property "Datasheet" "" (at %s %s 0)\n'
         '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
         % (libid, fmt(x), fmt(y), rot, hx(ref + str(x) + str(y)), ref,
            fmt(x), fmt(y - 2.54), val, fmt(x), fmt(y + 2.54),
            FPS.get(libid, ""), fmt(x), fmt(y), fmt(x), fmt(y)))
    if mpn:
        s += '\t\t(property "MPN" "%s" (at %s %s 0)\n\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n' % (mpn, fmt(x), fmt(y))
    s += '\t)\n'
    BODY.append(s)

def emit_label(net, x, y, rot=0):
    BODY.append('\t(label "%s" (at %s %s %d)\n'
                '\t\t(effects (font (size 1.27 1.27)) (justify left bottom))\n'
                '\t\t(uuid "%s"))\n' % (net, fmt(x), fmt(y), rot, hx("L" + net + str(x) + str(y))))

def emit_hlabel(net, x, y, rot=0):
    BODY.append('\t(hierarchical_label "%s" (shape input) (at %s %s %d)\n'
                '\t\t(effects (font (size 1.27 1.27)) (justify left))\n'
                '\t\t(uuid "%s"))\n' % (net, fmt(x), fmt(y), rot, hx("H" + net + str(x) + str(y))))

GNDN = [0]
def emit_gnd(x, y):
    GNDN[0] += 1
    ref = "#PWR0M%03d" % GNDN[0]
    BODY.append('\t(symbol (lib_id "power:GND") (at %s %s 0) (unit 1)\n'
                '\t\t(in_bom yes) (on_board yes) (dnp no)\n'
                '\t\t(uuid "%s")\n'
                '\t\t(property "Reference" "%s" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
                '\t\t(property "Value" "GND" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27))))\n'
                '\t\t(property "Footprint" "" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
                '\t\t(property "Datasheet" "" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
                '\t)\n' % (fmt(x), fmt(y), hx(ref + str(x) + str(y)), ref,
                           fmt(x), fmt(y - 2.54), fmt(x), fmt(y + 2.54),
                           fmt(x), fmt(y), fmt(x), fmt(y)))

def emit_noconn(x, y):
    NOCONN.append('\t(no_connect (at %s %s) (uuid "%s"))\n' % (fmt(x), fmt(y), hx("NC" + str(x) + str(y))))

def endpoint(libid, num, cx, cy):
    # symbol-library coords are Y-up; schematic page coords are Y-down
    dx, dy = SYMPINS[libid][num]
    return (rnd(cx + dx), rnd(cy - dy))

def place(ref, libid, val, x, y, netmap, mpn=""):
    """netmap: pin number -> net name | 'GND' | None(no-connect)."""
    emit_symbol(ref, libid, val, x, y, mpn=mpn)
    for num, net in netmap.items():
        ex, ey = endpoint(libid, num, x, y)
        if net == "GND":
            emit_gnd(ex, ey)
        elif net is None:
            emit_noconn(ex, ey)
        else:
            emit_label(net, ex, ey)

# ---------------- MCU ----------------
MX, MY = 200.66, 149.86
SYMPINS["ROXX_MCU:STM32H743VIT6"] = MCU_PINS
sig_by_num = {num: sig for num, sig, _ in PINS}
SPECIAL = {"NRST": "NRST", "BOOT0": "BOOT0"}
OSC = {"PH0-OSC_IN": "HSE_IN", "PH1-OSC_OUT": "HSE_OUT"}
DEBUG = {"PA13": "SWDIO", "PA14": "SWCLK", "PB3": "SWO"}
LEDS = {"PD15": "LED_RED_N", "PD11": "LED_GREEN_N", "PB15": "LED_BLUE_N"}
mcu_netmap = {}
full_sig = {num: sig for num, sig, _ in PINS}
for num, sig, et in PINS:
    if sig in ("VDD", "VDDA", "VBAT") or sig.startswith("PDR_ON"):
        mcu_netmap[num] = "CORE_3V3" if sig != "VDDA" else "VDDA"
    elif sig == "VREF+":
        mcu_netmap[num] = "VREFP"
    elif sig in ("VSS", "VSSA"):
        mcu_netmap[num] = "GND"
    elif sig == "VCAP":
        # first VCAP contact -> VCAP1, second -> VCAP2
        mcu_netmap[num] = "VCAP1" if "VCAP1" not in mcu_netmap.values() else "VCAP2"
    elif sig in SPECIAL:
        mcu_netmap[num] = SPECIAL[sig]
    elif sig in OSC:
        mcu_netmap[num] = OSC[sig]
    elif sig in DEBUG:
        mcu_netmap[num] = DEBUG[sig]
    elif sig in LEDS:
        mcu_netmap[num] = LEDS[sig]
    else:
        mcu_netmap[num] = None   # no-connect until increment 2b
place("U7", "ROXX_MCU:STM32H743VIT6", "STM32H743VIT6", MX, MY, mcu_netmap, mpn="STM32H743VIT6")

# ---------------- decoupling row (CORE_3V3) ----------------
y = 236.22
for k, x in enumerate((152.4, 160.02, 167.64, 175.26)):
    place("C%d" % (40 + k), "Device:C_Small", "100n X7R 6.3V", x, y,
          {"1": "CORE_3V3", "2": "GND"}, mpn="CC0402KRX7R7BB104")
place("C44", "Device:C_Small", "4u7 X7R 6.3V", 185.42, y,
      {"1": "CORE_3V3", "2": "GND"}, mpn="CL05A475KP5NNNC")

# hierarchical label + one PWR-local anchor on the first decoupling cap top pin
hx_, hy_ = endpoint("Device:C_Small", "1", 152.4, y)
emit_hlabel("CORE_3V3", hx_, hy_, 180)

# ---------------- VDDA / VREF+ filter ----------------
y = 220.98
place("FB1", "Device:FerriteBead_Small", "FB 600R@100MHz 0402", 139.7, y,
      {"1": "CORE_3V3", "2": "VDDA"}, mpn="BLM15AG601SN1D")
place("C45", "Device:C_Small", "100n X7R 6.3V", 147.32, y,
      {"1": "VDDA", "2": "GND"}, mpn="CC0402KRX7R7BB104")
place("C46", "Device:C_Small", "1u X7R 6.3V", 154.94, y,
      {"1": "VDDA", "2": "GND"}, mpn="CL05A105KA5NNNC")
place("FB2", "Device:FerriteBead_Small", "FB 600R@100MHz 0402", 162.56, y,
      {"1": "VDDA", "2": "VREFP"}, mpn="BLM15AG601SN1D")
place("C47", "Device:C_Small", "100n X7R 6.3V", 170.18, y,
      {"1": "VREFP", "2": "GND"}, mpn="CC0402KRX7R7BB104")
place("C48", "Device:C_Small", "1u X7R 6.3V", 177.8, y,
      {"1": "VREFP", "2": "GND"}, mpn="CL05A105KA5NNNC")

# ---------------- VCAP ----------------
y = 205.74
place("C49", "Device:C_Small", "2u2 X7R 6.3V VCAP1", 139.7, y,
      {"1": "VCAP1", "2": "GND"}, mpn="CL05A225KO5NNNC")
place("C50", "Device:C_Small", "2u2 X7R 6.3V VCAP2", 147.32, y,
      {"1": "VCAP2", "2": "GND"}, mpn="CL05A225KO5NNNC")

def emit_pwrflag(x, y):
    ref = "#FLG0M%03d" % (GNDN[0] + 100)
    GNDN[0] += 1
    BODY.append('\t(symbol (lib_id "power:PWR_FLAG") (at %s %s 0) (unit 1)\n'
                '\t\t(in_bom yes) (on_board yes) (dnp no)\n'
                '\t\t(uuid "%s")\n'
                '\t\t(property "Reference" "%s" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
                '\t\t(property "Value" "PWR_FLAG" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27))))\n'
                '\t\t(property "Footprint" "" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
                '\t\t(property "Datasheet" "" (at %s %s 0)\n'
                '\t\t\t(effects (font (size 1.27 1.27)) (hide yes)))\n'
                '\t)\n' % (fmt(x), fmt(y), hx(ref + str(x) + str(y)), ref,
                           fmt(x), fmt(y - 2.54), fmt(x), fmt(y + 2.54),
                           fmt(x), fmt(y), fmt(x), fmt(y)))

# PWR_FLAGs on filtered/standalone power nets (driven through passive ferrites)
for cx, cy in ((147.32, 220.98), (170.18, 220.98), (139.7, 205.74), (147.32, 205.74)):
    ex, ey = endpoint("Device:C_Small", "1", cx, cy)
    emit_pwrflag(ex, ey)

# ---------------- BOOT0 pulldown + recovery pad ----------------
place("R40", "Device:R_Small", "10k BOOT0 PD", 241.3, 205.74,
      {"1": "BOOT0", "2": "GND"}, mpn="RC0402FR-0710KL")
place("TP40", "Connector:TestPoint", "BOOT0_REC", 248.92, 205.74, {"1": "BOOT0"})

# ---------------- NRST: 10k PU + 100n + TP ----------------
place("R41", "Device:R_Small", "10k NRST PU", 241.3, 213.36,
      {"1": "CORE_3V3", "2": "NRST"}, mpn="RC0402FR-0710KL")
place("C51", "Device:C_Small", "100n X7R 6.3V", 248.92, 213.36,
      {"1": "NRST", "2": "GND"}, mpn="CC0402KRX7R7BB104")
place("TP41", "Connector:TestPoint", "NRST", 256.54, 213.36, {"1": "NRST"})

# ---------------- SWD 6-pin ----------------
place("J40", "Connector_Generic:Conn_01x06", "SWD 6p", 276.86, 152.4,
      {"1": "SWDIO", "2": "SWCLK", "3": "SWO", "4": "NRST", "5": "CORE_3V3", "6": "GND"},
      mpn="SM06B-SRSS-TB")

# ---------------- HSE 16 MHz ----------------
place("Y1", "Device:Crystal", "16 MHz", 139.7, 149.86,
      {"1": "HSE_IN", "2": "HSE_OUT"}, mpn="ABM8-16.000MHZ-B2-T")
place("C52", "Device:C_Small", "12p C0G PLACEHOLDER", 147.32, 144.78,
      {"1": "HSE_IN", "2": "GND"})
place("C53", "Device:C_Small", "12p C0G PLACEHOLDER", 154.94, 144.78,
      {"1": "HSE_OUT", "2": "GND"})

# ---------------- status LEDs (active low) ----------------
for k, (net, rr, dd) in enumerate((("LED_RED_N", "R42", "D40"),
                                   ("LED_GREEN_N", "R43", "D41"),
                                   ("LED_BLUE_N", "R44", "D42"))):
    x = 241.3 + k * 12.7
    place(rr, "Device:R_Small", "1k", x, 231.14, {"1": "CORE_3V3", "2": "LEDK%d" % k},
          mpn="RC0402FR-071KL")
    place(dd, "Device:LED", net, x, 241.3, {"2": "LEDK%d" % k, "1": net})

# ---------------- assemble ----------------
sch = """(kicad_sch
\t(version 20250114)
\t(generator "roxx_gen_mcu_sch")
\t(generator_version "9.0")
\t(uuid "00000000-0000-4000-8000-000000000c01")
\t(paper "A3")
\t(title_block
\t\t(title "ROXX FC Rev A - MCU Core")
\t\t(company "ROXX")
\t\t(rev "A0")
\t\t(date "2026-10-19")
\t\t(comment 1 "Stage 4 inc.2 v1: MCU core, power/reset/boot/SWD/HSE/LEDs. IO pins no-connect until inc.2b. Not routed. Not flight-ready.")
\t)
\t(lib_symbols
%s
%s
\t)
%s%s
\t(sheet_instances
\t\t(path "/00000000-0000-4000-8000-000000000c02" (page "2"))
\t)
)
""" % ("".join(EMB_BLOCKS.values()), MCU, "".join(BODY), "".join(NOCONN))
open(os.path.join(HERE, "roxx_mcu.kicad_sch"), "w").write(sch)

# project symbol library (so lib_id ROXX_MCU:... resolves outside the embed too)
libsym = ('(kicad_symbol_lib (version 20241011) (generator "roxx_gen_mcu_sch") (generator_version "9.0")\n'
          + MCU.replace('(symbol "ROXX_MCU:STM32H743VIT6"', '(symbol "STM32H743VIT6"', 1)
          + ')\n')
open(os.path.join(HERE, "roxx_mcu.kicad_sym"), "w").write(libsym)

table = ('(sym_lib_table\n'
         '  (lib (name "ROXX_PWR")(type "KiCad")(uri "${KIPRJMOD}/roxx_power.kicad_sym")(options "")(descr "ROXX power symbols"))\n'
         '  (lib (name "ROXX_MCU")(type "KiCad")(uri "${KIPRJMOD}/roxx_mcu.kicad_sym")(options "")(descr "ROXX MCU symbols"))\n'
         ')\n')
open(os.path.join(HERE, "sym-lib-table"), "w").write(table)
print("wrote roxx_mcu.kicad_sch:", len(sch), "bytes;", len(PINS), "MCU pins;",
      len(NOCONN), "no-connects;", GNDN[0], "GND symbols")
