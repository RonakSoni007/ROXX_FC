# Change log

- 2026-10-18: Created project directory. Extracted `Nxt-FC-Hardware-NxtDual.zip` to a read-only reference copy (SHA-256 41fca550...f9f8a2). No original files changed.
- 2026-10-18: Wrote hardware_audit.md (Stage 1). Findings: STM32H743 + 2x BMI088 + SPL06, BSD-3-Clause, no firmware in repo, power tree unsuitable for Pi 5 without verification, ERC/DRC not run.
- 2026-10-18 (Stage 2): Verified `boards/hkust/nxt-dual` exists on PX4 `main`; recorded discrepancies F-1..F-7 (board ID 1013 copied from Matek, PB5, buzzer, etc.).
- 2026-10-18 (Stage 2): Wrote requirements.md, architecture.md, architecture_decision_matrix.md, interface_specification.md, power_tree.md, firmware_integration.md, bom_preliminary.csv. All recommendations awaiting approval; no datasheets retrieved; no routing started.
- 2026-10-18 (Stage 2): Correction to Stage 1 audit: the vendor claim about the PX4 target is now verified in the PX4 repository (see firmware_integration.md).
