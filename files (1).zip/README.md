# ROXX Flight Controller (custom PX4 hardware)

Working directory for the ROXX quadcopter flight-controller development. The imported NxtPX4 Dual repository is preserved separately and is not modified.

## Deliverable status

| Deliverable | Status |
|---|---|
| README.md | partial |
| requirements.md | partial (Stage 2, proposals await approval) |
| architecture.md | partial (recommendation, awaiting approval) |
| hardware_audit.md | **complete (static inspection; ERC/DRC and netlist outstanding)** |
| interface_specification.md | partial (pin table preliminary, AFs unverified) |
| power_tree.md | partial (assumption-based, no regulator selected) |
| firmware_integration.md | partial (PX4 target verified; ROXX board not built) |
| validation_plan.md | not started |
| architecture_decision_matrix.md | complete (Stage 2) |
| bom_preliminary.csv | partial (no datasheet verification) |
| change_log.md | partial |
| KiCad project, BOM, libraries | blocked: awaiting approved architecture |

## Stage

STAGE 1 and STAGE 2 documents written. Next: STAGE 3 (your approvals), then STAGE 4.

## Decisions pending

See architecture.md section 9. No routing starts until approved.
