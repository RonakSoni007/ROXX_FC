# ROXX Flight Controller: Interface Specification (preliminary)

Status: **partial (Stage 2).** Pin allocation is preliminary and **must be reviewed before schematic capture or routing.** No STM32H743 datasheet alternate-function table was retrieved this session, so any pin marked **R** (recommendation) has an unchecked AF and must be verified before it is committed.

Status codes used in the tables:
- **V** = taken from the PX4 `boards/hkust/nxt-dual` files I fetched from `main` (board_config.h, board.h, spi.cpp, i2c.cpp, timer_config.cpp, defconfig, default.px4board), so this pin/AF pair exists in a shipping PX4 target. Not yet checked against the ST datasheet.
- **R** = my recommendation, AF unverified.
- **D** = discrepancy between sources, needs a decision.

## 1. MCU pin allocation (STM32H743VIH6, TFBGA100)

### 1.1 Sensors and storage

| Function | Signal | Pin | Peripheral | Status | Notes |
|---|---|---|---|---|---|
| IMU0 (proposed ICM-42688-P) | SCK / MISO / MOSI | PA5 / PA6 / PA7 | SPI1 | V (pins), R (device) | Reference uses these for BMI088 #0 |
| IMU0 | CS | PA3 | GPIO | R | Reuses reference gyro CS |
| IMU0 | INT | PA1 | EXTI1 | R | Reuses reference gyro DRDY. PA2 and PA0 become spare |
| IMU1 (BMI088) | SCK / MISO / MOSI | PE2 / PE5 / PE6 | SPI4 | V | |
| IMU1 | Gyro CS / Accel CS | PC2 / PC13 | GPIO | V | PC13 is a backup-domain pin with limited output drive on STM32 [general knowledge, verify]; fine for a slow CS |
| IMU1 | Gyro DRDY / Accel DRDY | PE3 / PE4 | EXTI3 / EXTI4 | V | |
| Barometer (proposed BMP388) | SCL / SDA | PB6 / PB7 | I2C1 | V (bus) | PX4 reference starts the baro on I2C1 |
| Barometer | INT / address | PB5 | EXTI5 or GPIO | **D** | Hardware spreadsheet says baro data-ready; PX4 `board_config.h` defines PB5 as `GPIO_SPL_ADDR_SET` output. ROXX: hardwire the address, leave PB5 as optional INT, delete the address-set GPIO |
| Flash / FRAM footprint | SCK / MISO / MOSI / CS | PD3 / PB14 / PC3 / PD4 | SPI2 (DMA) | V | Reference registers it as `SPIDEV_FLASH(0)`; keep as optional |
| microSD (4-bit) | D0-D3, CK, CMD | PC8, PC9, PC10, PC11, PC12, PD2 | SDMMC1 | V | |

### 1.2 Motors, buzzer, LEDs

| Function | Signal | Pin | Timer | Status | Notes |
|---|---|---|---|---|---|
| Motor 1-4 (DShot/PWM, same group) | CH1-CH4 | PE9, PE11, PE13, PE14 | TIM1 CH1-4 | V | One timer group, one protocol (D-04). 3.3 V push-pull |
| Motor/AUX 5-6 (optional) | CH3, CH4 | PB10, PB11 | TIM2 | V | Separate group, can run servo PWM |
| Buzzer (proposed) | tone | PB0 | TIM3 CH3 | R | PX4 `fmu-v6c` drives tone from TIM3 CH3 on PB0; here PB0 was a motor output in the reference, so the pin is verified for TIM3_CH3 but the tone-alarm use is new |
| Spare PWM | CH4 | PB1 | TIM3 CH4 | V (pin) | |
| LEDs (active low) | R / G / B | PD15 / PD11 / PB15 | GPIO | V | `GPIO_nLED_*` |
| AUX GPIO | AUX1-3 | PC0, PC1, PA4 | GPIO | V | PA4 is `GPIO_BUZZER_1` in the reference firmware, which conflicts with AUX3 in the schematic |
| HRT | internal | none | TIM8 | V | PX4 uses TIM8 CH1 for the high-resolution timer; do not use TIM8 outputs |

### 1.3 Serial ports

| PX4 name | NuttX | Port | TX | RX | DMA | ROXX role | Status |
|---|---|---|---|---|---|---|---|
| GPS1 | ttyS0 | USART1 | PA9 | PA10 | no | **External GNSS** | V |
| TEL1 | ttyS1 | USART2 | PD5 | PD6 | no | **Telemetry radio** | V |
| GPS2 | ttyS2 | USART3 | PD8 | PD9 | no | Second GNSS / spare | V |
| **TEL2** | ttyS3 | **UART4** | PB9 | PB8 | **yes (RX, TX)** | **Raspberry Pi 5 MAVLink** | V |
| RC | ttyS4 | UART5 | PB13 | PB12 | no | **RC receiver** | V |
| console | ttyS5 | USART6 | PC6 | PC7 | no | **NSH debug console** | V (not wired in reference HW) |
| TEL3 | ttyS6 | UART7 | PE8 (NC) | PE7 | no | **ESC telemetry (RX only)** | V |
| TEL4 | ttyS7 | UART8 | PE1 | PE0 | no | Spare | V |

Source for the mapping: `default.px4board` (`BOARD_SERIAL_*`) and `defconfig`. The vendor's published PX4 mapping (TELEM1 UART2, TELEM2 UART4, TELEM3 UART7, GPS1 UART1, GPS2 UART3, RC UART5) agrees.

### 1.4 Other

| Function | Signal | Pin | Status | Notes |
|---|---|---|---|---|
| USB FS device | DM / DP | PA11 / PA12 | V | |
| USB VBUS detect | VBUS | PD0 | V | PD0 is also an FDCAN1 pin on STM32 [general knowledge, verify]; if CAN is added in rev B this must move |
| SWD | SWDIO / SWCLK | PA13 / PA14 | V | Do not use SWO: PB3 is SPI3 SCK |
| Reset / boot | NRST, BOOT0 | dedicated | V (reference has a BOOT button) | Add a test pad for each |
| Battery voltage | ADC12 ch 4 | PC4 | V | Divider default in PX4 board defaults is 10.1 (about 33.3 V full scale at 3.3 V) |
| Battery current | ADC12 ch 8 | PC5 | V | Default 17 A/V in board defaults, to be recalibrated for the ROXX sensor |
| I2C4 expansion | SCL / SDA | PD12 / PD13 | V | External compass / optional sensors |
| SPI3 pads | SCK / MISO / MOSI | PB3 / PB4 / PB2 | V | Unused in the reference |
| SBUS invert (optional) | control | PD14 | V (spreadsheet only) | Commented out in PX4 code; reference inverts in hardware with an XOR gate and a 0R option |
| Clocks | HSE 16 MHz, LSE 32.768 kHz | PH0/PH1, PC14/PC15 | V | `STM32_BOARD_XTAL` is 16 MHz in `board.h`, PLL1 gives 480 MHz |

## 2. Conflicts and checks

| # | Item | Finding | Action |
|---|---|---|---|
| C-1 | PB5 | Baro data-ready vs PX4 address-set GPIO | Resolve in schematic; remove the GPIO from the ROXX board_config |
| C-2 | PA4 | Schematic AUX3 vs firmware buzzer GPIO | Move buzzer to PB0 TIM3_CH3 (R) |
| C-3 | PB0 / PB1 | Reference motor outputs 5-6 on TIM3; ROXX uses PB0 for tone | Motors 5-6 move to TIM2 (PB10/PB11) |
| C-4 | PB3 | SWO and SPI3 SCK share the pin | SWO unused |
| C-5 | PD0 | VBUS detect blocks FDCAN1 on rev B | Relocate before adding CAN |
| C-6 | DMA | `timer_config.cpp` assigns all three IO timers to DMA index 1; defconfig enables DMA on UART4 and SPI2 only, plus BDMA/DMA1/DMA2 | No static conflict found in the fetched files. Must be re-checked with a real build and runtime DMA allocation, especially once ICM-42688-P replaces one BMI088 |
| C-7 | TIM8 | Used by HRT | Do not assign TIM8 outputs |
| C-8 | Hardware vs firmware | Hardware spreadsheet and `.ioc` disagree on several pins (PC2, PC3, PB3, PB4, PD14) | Reconcile with netlist at schematic stage |
| C-9 | `board.h` comments | Mentions "PBA10", "PB8 NC" for USART1_CK, which is PA8 | Cosmetic, fix in ROXX copy |
| C-10 | IDs | `firmware.prototype` and `hw_config.h` use board ID 1013 and a "MatekH743-slim" description | ROXX needs its own ID and text |

## 3. Connectors (proposal; pin order fixed at schematic review)

Connector family P-05: JST-GH (Pixhawk-style) pending approval. All signal logic is 3.3 V. Current ratings must be checked against the chosen housings.

| Connector | Signals | Rail | Notes |
|---|---|---|---|
| GNSS (GPS1) | 5 V, TX, RX, GND (+ SCL, SDA if module has a compass) | 5 V FC rail | Module not selected; PPS has no allocated pin (R: use PC0/PC1 if needed) |
| Telemetry (TEL1) | 5 V, TX, RX, GND | 5 V FC rail | Radio not selected |
| RC (UART5) | 5 V, RX, TX, GND | 5 V FC rail | Protocol not selected. Keep the inverter option for SBUS; CRSF is non-inverted |
| ESC | M1-M4 signals, GND (multiple), ESC telemetry RX, current sense in | none from FC to ESC power | Pinout depends on the ESC: **blocked until the ESC is chosen** |
| Companion (UART4) | TX, RX, GND | none | See 4 |
| USB-C | VBUS, D+, D- | 5 V (bench) | ORed with the 5 V FC rail |
| Debug | SWDIO, SWCLK, NRST, 3V3, GND; separate USART6 console header | 3.3 V | Test pads for BOOT0 |
| I2C4 / AUX | SCL, SDA, 5 V, GND | 5 V | Optional |
| Pi power out | 5.1 V, GND (several pins) | Pi rail | Current rating must support 5 A; see power_tree.md |

## 4. Raspberry Pi 5 link

| FC | Pi 5 header (general knowledge, confirm on the Pi pinout) | Notes |
|---|---|---|
| PB9 (UART4 TX) | GPIO15 RXD0, pin 10 | 3.3 V logic both sides |
| PB8 (UART4 RX) | GPIO14 TXD0, pin 8 | |
| GND | pin 6 (and others) | Common signal reference, short return |

PX4 side: `MAV_1_CONFIG = TELEM2`, `SER_TEL2_BAUD = 921600` (the PX4 docs example shows 57600 by default and use of `/dev/ttyAMA0` on the Pi; both documented). A MAVSDK or ROS 2 application runs on the Pi. If uXRCE-DDS is preferred, the same port is configured with `MAV_1_CONFIG = 0`, `UXRCE_DDS_CFG = 102`. Flow control is not wired in rev A (UART4 RTS/CTS pins not allocated); at 921600 with DMA this is a recommendation to validate, not a verified result.

OAK-D Lite connects to a Pi USB 3 port and never touches the FC.

## 5. Unverified items

- STM32H743 AF table, voltage tolerances and package pin map not retrieved.
- ICM-42688-P and BMP388 pinouts and footprints not retrieved.
- ESC connector pinout and ESC protocol compatibility.
- Pi 5 header pin numbers are from general knowledge.
