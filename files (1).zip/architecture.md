# ROXX Flight Controller: Architecture (preliminary, Stage 2)

Status: **partial. Recommendation only, not approved.** Do not start schematic capture or routing until the decisions in section 9 are signed off and the pin table in `interface_specification.md` is reviewed.

Tags: [V] verified this session from a cited source. [R] recommendation. [A] assumption. [U] unverified.

## 1. Summary

| Item | Recommendation |
|---|---|
| MCU | STM32H743VIH6 (TFBGA100), 480 MHz, 2 MB flash [V: reference schematic, PX4 board.h]. Fallback: LQFP100 variant [U pin map] |
| IMUs | ICM-42688-P on SPI1 + BMI088 on SPI4 (dissimilar redundancy) [R]; dual-BMI088 fallback [V in PX4] |
| Barometer | BMP388 on I2C1 [R]; driver [V in PX4 tree] |
| GNSS | External, USART1 (GPS1), 5 V supply, 3.3 V logic [R] |
| ESC | TIM1 CH1-4 on PE9/PE11/PE13/PE14, DShot-capable [V in PX4 reference]; ESC choice open |
| Companion | UART4 (TEL2) with DMA at 921600, MAVLink 2 [V in PX4 reference] |
| Power | 3S-6S proposed [R]; separate FC 5 V buck and a 5 A Pi 5 buck [R] |
| Firmware | New `boards/roxx/fc-v1/` copied from `hkust/nxt-dual` [R] |
| Board target | `hkust_nxt-dual` verified on PX4 `main` [V] |

## 2. System block diagram

```mermaid
flowchart LR
  BAT[Battery 3S-6S] --> PROT[Reverse FET + TVS + fuse]
  BAT --> ESC[4-in-1 ESC]
  ESC --> M1[Motor 1]
  ESC --> M2[Motor 2]
  ESC --> M3[Motor 3]
  ESC --> M4[Motor 4]
  PROT --> BA[Buck A 5V FC]
  PROT --> BB[Buck B 5.1V 5A Pi]
  BA --> L3[3V3 rails]
  L3 --> MCU[STM32H743 PX4]
  L3 --> IMU0[ICM-42688-P SPI1]
  L3 --> IMU1[BMI088 SPI4]
  L3 --> BARO[BMP388 I2C1]
  L3 --> SD[microSD SDMMC1]
  BA --> GNSS[External GNSS]
  BA --> RC[RC receiver]
  BA --> TEL[Telemetry radio]
  GNSS -- USART1 --> MCU
  RC -- UART5 --> MCU
  TEL -- USART2 --> MCU
  MCU -- TIM1 DShot/PWM --> ESC
  ESC -- UART7 RX telemetry --> MCU
  MCU -- UART4 MAVLink 921600 --> PI[Raspberry Pi 5]
  BB --> PI
  PI -- USB3 --> CAM[OAK-D Lite]
  USB[USB-C] --> MCU
  SWD[SWD + USART6 console] --> MCU
```

ASCII equivalent:

```
Battery -> [protect] -> Buck A (5V FC) -> 3V3 -> MCU, IMU0 (SPI1), IMU1 (SPI4), baro (I2C1), SD
                     |                -> GNSS (USART1), RC (UART5), telemetry (USART2)
                     -> Buck B (5.1V 5A) -> Pi 5 -> USB3 -> OAK-D Lite
Battery -> ESC -> 4 motors      MCU --TIM1--> ESC      ESC --UART7 RX--> MCU
MCU --UART4 MAVLink--> Pi 5     USB-C and SWD/USART6 console for service
```

The Pi sits off the flight-critical path: sensor sampling, EKF2, rate control and motor outputs run on the MCU. The Pi link only carries setpoints, telemetry and perception results. [R, consistent with R-06]

## 3. MCU and PX4 support strategy

Selected on verified PX4 support, not performance. The `hkust/nxt-dual` board directory in PX4 `main` defines this exact MCU, its clock tree (16 MHz HSE, 480 MHz), SDMMC, USB, seven UARTs, SPI1-4, I2C1/4, ADC and timers. ROXX copies and adapts it (firmware_integration.md). The reference hardware files have a 4-layer stack and 0.1 mm design rules that I regard as tight for a first spin; the fab capability must be confirmed.

## 4. Sensors

IMU0 and IMU1 sit on separate SPI buses with separate data-ready lines. Placement guidance [R]: both IMUs near the board centre, away from the Pi buck and the ESC wiring, ideally on a mechanically isolated area, with foam over the barometer and a small notch or slot to reduce thermal and vibration coupling. Quantitative vibration and thermal analysis is not done. Sensor orientation is set in `rc.board_sensors` with `-R`; the reference uses `-R 2` for both BMI088s.

## 5. Preliminary BOM

Full list in `bom_preliminary.csv`. Only items the reference schematic actually uses are marked as such; datasheets for every row are **not yet verified**.

| Ref | Function | Candidate | Basis |
|---|---|---|---|
| U1 | MCU | STM32H743VIH6 | In reference schematic |
| U2 | IMU0 | ICM-42688-P | Proposed; footprint and STEP in reference library, licence unverified |
| U3 | IMU1 | BMI088 | In reference schematic (x2) |
| U4 | Baro | BMP388 | Proposed; SPL06 in reference |
| Y1 | HSE 16 MHz | SG-210STF oscillator (X1G004171002700) | In reference |
| Y2 | LSE 32.768 kHz | ABS07 | In reference |
| U5 | Buck A (FC 5 V) | TBD, input rating 40 V or higher | Reference MP9943GQ-Z is marginal for 6S |
| U6 | Buck B (Pi 5.1 V, 5 A) | TBD | None in reference |
| U7 | 3V3 regulation | TBD, 1 A or more | Reference RT9013-33GB is 500 mA |
| Q1 | Reverse protection | AP40P05 or ideal-diode controller | In reference |
| D1 | TVS | SMF30CA-class, re-evaluated | In reference |
| U8 | Flash | W25Q128JVS | In reference (optional footprint) |
| J | SD socket | TF-SMD_TF-021B-H265 | In reference |
| U9 | SBUS inverter | SN74LVC1G86 | In reference |
| BZ | Buzzer driver | TBD | New |
| U10 | Power monitor | INA228 | Optional |

## 6. Licensing and third-party assets (task 7)

Repository licence: BSD-3-Clause, Copyright (c) 2023 Peize-Liu [V]. PX4 board files are BSD-3-Clause with PX4 Development Team headers [V from the fetched sources]. Neither is legal advice.

| Asset | Finding | Action before redistribution |
|---|---|---|
| Schematic and PCB (`NxtPX4.kicad_sch/_pcb`) | Covered by the repo BSD-3-Clause | Keep copyright notice and licence; no use of the authors' names to endorse |
| Standard KiCad symbols (Device, Connector, Power, Switch, Diode, Memory_Flash, Mechanical) | From KiCad's official libraries, which have their own licence [U exact terms: general knowledge says CC-BY-SA 4.0 with a design exception] | Verify against the KiCad version used |
| `NxtPX4_Symbol.kicad_sym` (15 placed symbols) | Project library. Four symbol/footprint files contain licence/vendor strings (`lcsc` appears 3 times); origin not stated | Check each part's source (likely distributor-generated) |
| `NxtPX4.pretty` footprints | Mixed. Four files contain provenance strings (TPSM63603EXTRDHR, ICM-20649, ICM-42688-P, USB_C_Small) | Verify; re-draw from datasheets for anything unclear |
| Logos and signatures: `HKU_Logo`, `HILAB_Logo`, `NxtLOGO`, `Dual_logo`, `Uav_logo`, `Ri_logo`, `my_signature`, `Decoration_*` | Institutional or personal branding | **Do not carry into ROXX** |
| STEP models (24) | Headers show vendor-style names (CSP-USC16 / CQ-USB-C16PSMT01, MPM3515, ICM42688-P, SG-210STF, BMP388, TFBGA100, SD card, JST SH variants). Author/organisation fields are empty | Treat as unlicensed for redistribution until each source is identified; regenerate or obtain manufacturer models |
| `Nxt*` PNG renders and PDFs | Part of the repo licence but contain branding | Do not reuse images |

Unused models in the library (ICM-20649, MPM3515, TPSM63603) are not placed in the schematic [V from component list]; do not import them.

## 7. Risks and unresolved technical decisions

| ID | Risk | Severity | Next step |
|---|---|---|---|
| K-1 | PX4 support status (supported-hardware list category, CI) unconfirmed | Medium | Check PX4 docs list and release tags |
| K-2 | No datasheets retrieved for MCU, IMUs, baro, regulators, GNSS | High | Obtain and review before schematic |
| K-3 | Pi 5 5 A rail: thermal (2.2-3.5 W loss), connector rating, backfeed protection | High | Select regulator, thermal test |
| K-4 | Pi USB current limit with GPIO supply (600 mA unless configured) could starve OAK-D Lite | High | Configure and verify on bench |
| K-5 | 3V3 rail may exceed a 500 mA LDO under assumed loads | Medium | Measure; size at 1 A or more |
| K-6 | 6S transients versus regulator input ratings; ESC spike data absent | High | Choose 40 V or higher parts; measure with the real ESC |
| K-7 | ESC unknown ("Bluejay-compatible"); telemetry and DShot support in PX4 unverified | High | Pick ESC; verify protocol |
| K-8 | Battery, motors, current and airframe not defined | High | Needs your input |
| K-9 | TFBGA100 and 0.1 mm rules: fab and assembly yield | Medium | Fab quote and DFM review; consider LQFP fallback |
| K-10 | DMA/timer allocation after changing IMU and buzzer | Medium | Build and test target |
| K-11 | Pin discrepancies (PB5, PA4, spreadsheet vs ioc) | Medium | Resolve with netlist |
| K-12 | Dissimilar IMU choice changes bring-up effort; ICM-42688-P availability unverified | Medium | Confirm availability; keep dual-BMI088 fallback |
| K-13 | Third-party model/footprint licences | Medium | Section 6 actions |
| K-14 | GNSS module, RC protocol, telemetry radio undefined | Medium | Needs your input |
| K-15 | PX4 board ID 1013 collision | Low | Allocate new ID |
| K-16 | Vendor sources disagree (baro part, MP9943 input maximum) | Low | Resolve with datasheets |

## 8. Sources

Accessed this session: PX4 board files and docs (firmware_integration.md section 8); Raspberry Pi "USB Power Delivery on Raspberry Pi 5" white paper (pip-assets.raspberrypi.com); element14 Raspberry Pi 5 FAQ; Luxonis OAK-D Lite datasheet excerpt (core-electronics.com.au) and shop page (shop.luxonis.com); MicoAir NxtPX4v2 page; ArduPilot NxtPX4v2 page; distributor listings for MP9943GQ-Z. Not retrieved: ST, Bosch, TDK InvenSense, Goertek, Richtek and GNSS datasheets.

## 9. Decisions that need your approval

1. Battery input range 3S-6S (or tell me your pack).
2. IMU choice: ICM-42688-P + BMI088 (recommended) or dual BMI088.
3. Barometer: BMP388 (recommended) or keep SPL06.
4. CAN deferred to rev B.
5. Connector family: JST-GH or JST-SH.
6. Pi supply approach: on-board 5 A buck (recommended) or an external BEC.
7. ESC model and the RC protocol / GNSS module you intend to use.
