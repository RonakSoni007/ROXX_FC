# ROXX Flight Controller: PX4 Firmware Integration Strategy

Status: **partial (Stage 2). Nothing has been built or flashed.** This document separates what I verified in the PX4 repository from what is planned.

## 1. Verification of the `hkust_nxt-dual` target (task 1)

**Result: VERIFIED that the target exists in the official PX4-Autopilot repository on `main`.** Checked on 2026-10-18 by fetching files from `raw.githubusercontent.com/PX4/PX4-Autopilot/main/boards/hkust/nxt-dual/`.

| Fact | Evidence |
|---|---|
| Path | `boards/hkust/nxt-dual/` (vendor `hkust`, model `nxt-dual`) |
| Files present | `default.px4board`, `firmware.prototype`, `init/rc.board_sensors`, `init/rc.board_defaults`, `src/board_config.h`, `src/spi.cpp`, `src/i2c.cpp`, `src/timer_config.cpp`, `src/init.c`, `src/sdio.c`, `src/usb.c`, `src/led.c`, `src/hw_config.h`, `nuttx-config/include/board.h`, `nuttx-config/nsh/defconfig`, `nuttx-config/scripts/script.ld`, `src/CMakeLists.txt` (all returned HTTP 200) |
| Architecture | `CONFIG_BOARD_ARCHITECTURE="cortex-m7"` |
| Drivers enabled | `CONFIG_DRIVERS_IMU_BOSCH_BMI088`, `CONFIG_COMMON_BAROMETERS`, `CONFIG_DRIVERS_DSHOT`, `CONFIG_DRIVERS_PWM_OUT`, `CONFIG_DRIVERS_GPS`, `CONFIG_DRIVERS_RC_INPUT`, `CONFIG_DRIVERS_ADC_BOARD_ADC`, `CONFIG_DRIVERS_TONE_ALARM`, `CONFIG_MODULES_MAVLINK`, `CONFIG_MODULES_UXRCE_DDS_CLIENT`, EKF2, commander, MC controllers, logger |
| Sensor start script | `bmi088` on SPI bus 1 and bus 4 (accel and gyro), then `spl06 -I -b 1 -a 0x77`, falling back to bus 4 |
| Serial map | GPS1 ttyS0, TEL1 ttyS1, GPS2 ttyS2, TEL2 ttyS3, RC ttyS4, TEL3 ttyS6, TEL4 ttyS7; UART4 has RX/TX DMA at 921600 default; USART6 is the NuttX console |
| Clock | 16 MHz HSE, PLL1 to 480 MHz SYSCLK |
| Maintenance | The atom feed for the board directory shows 20 commits through 2026-10-13. Most are repository-wide changes (NuttX 12.12.0 upgrade 2026-09-03, sensor classification refactor 2026-08-29, board_config cleanup 2026-08-06, bootloader ECC scrub update 2026-06-24). The last board-specific one I can identify is "hkust/nxt-dual: fix TIM3 channel order in timer config (#26667)" on 2026-03-05 |

What I **could not** verify:
- Whether the board appears on the PX4 docs "supported hardware" list, and in which maintenance category (Pixhawk standard / manufacturer-supported / community).
- Whether CI builds it for each release, and which release tags contain it.
- That it has ever been flight-tested by PX4 maintainers. MicoAir's page says NxtPX4v2 is officially supported, which matches the repository, but that is a vendor statement.

## 2. Discrepancies found in the reference target (matters for ROXX)

| # | Finding | Impact |
|---|---|---|
| F-1 | `firmware.prototype` says "Firmware for the MatekH743-slim board", summary "MatekH743-mini", `board_id` 1013, and `hw_config.h` sets `BOARD_TYPE 1013` | Copied metadata; ROXX must use its own ID and text. Do not reuse 1013 |
| F-2 | `board_config.h` defines PB5 as `GPIO_SPL_ADDR_SET` while the hardware spreadsheet uses PB5 as baro data-ready | Resolve at schematic review |
| F-3 | `GPIO_BUZZER_1` is PA4 and `GPIO_TONE_ALARM` points at the GPIO, not a timer; the schematic labels PA4 as AUX3 and a retailer states the board has no buzzer output | ROXX moves the tone to PB0 TIM3_CH3 (R) |
| F-4 | `BOARD_NUM_IO_TIMERS` is 5 but three `initIOTimer` entries exist; the comment says TIM1 is the HRT while `HRT_TIMER` is 8 | Confirm intent when copying |
| F-5 | `rc.board_defaults` sets `CBRK_SUPPLY_CHK 894281`, `SYS_HAS_MAG 0`, `BAT1_N_CELLS 4`, `BAT1_V_DIV 10.1`, `BAT1_A_PER_V 17` and some tuned rate-controller gains | Hardware- and airframe-specific; ROXX must set its own and re-justify `CBRK_SUPPLY_CHK` |
| F-6 | `bootloader/hw_config.h` returned 404, but `src/hw_config.h` exists and holds the bootloader settings (`APP_LOAD_ADDRESS 0x08020000`, USB + USART6 interfaces) | Note the bootloader config location when copying |
| F-7 | Retail listing says barometer DPS310; PX4 starts `spl06` | Confirm what is fitted before reusing the boot script |

## 3. Strategy for ROXX

1. **Create a new PX4 board** `boards/roxx/fc-v1/` by copying `boards/hkust/nxt-dual/` (BSD-3-Clause; keep the PX4 copyright headers and the licence). This follows the PX4 NuttX porting guide: copy the closest existing board and edit `default.px4board` (VENDOR/MODEL), `board.h`, `board_config.h`, `defconfig`, `hw_config.h`, `firmware.prototype`, and the init scripts.
2. Keep the proven H7 clock, SDMMC, USB, UART, ADC, timer and SPI definitions; change only what the ROXX hardware changes.
3. Planned changes versus the reference:

| Area | Change |
|---|---|
| IMU | Add `icm42688p` on SPI1 (CS PA3, INT PA1) in `spi.cpp` and `rc.board_sensors`; keep BMI088 on SPI4. Enable `CONFIG_DRIVERS_IMU_INVENSENSE_ICM42688P` |
| Baro | Replace the `spl06` lines with the driver for the chosen part (candidate `bmp388`) on I2C1; delete `GPIO_SPL_ADDR_SET` |
| Buzzer | Set `TONE_ALARM_TIMER 3`, `TONE_ALARM_CHANNEL 3`, `GPIO_TONE_ALARM` to TIM3_CH3 on PB0 (as in `px4/fmu-v6c`); remove PA4 buzzer |
| Motors | Four outputs TIM1 CH1-4; TIM2 CH3/4 as optional AUX; drop TIM3 from the IO-timer list |
| Companion | Keep UART4 with DMA at 921600 |
| Console | Wire USART6 to a header |
| Sensors defaults | New `BAT1_*` defaults for the ROXX divider and current sensor |
| Identity | New `board_id`, USB strings, description |
| Failsafe defaults | Set after Stage 3 decisions (see section 5) |

4. **Bootloader:** H7 bootloader is part of the PX4 firmware tree (PX4 NuttX porting guide). Build and flash plan: first load via SWD, then use the USB bootloader for updates. Recovery: SWD with a tag-connect or pads, BOOT0 pad for ST ROM bootloader.
5. **Build commands (pattern, to be confirmed on the ROXX target):** `make roxx_fc-v1_default` and the matching bootloader target. For the reference: vendor states `make hkust_nxt-dual`; the standard PX4 pattern is `make <vendor>_<model>_default`.
6. **Do not claim compatibility** until: the target builds, the bootloader flashes, each sensor driver starts and reports data, and the flight tests in validation_plan.md pass.

## 4. Mapping: schematic to firmware (traceability)

| Hardware item | Firmware item |
|---|---|
| IMU0 on SPI1 | `spi.cpp` `initSPIBus(SPI::Bus::SPI1, ...)`; `rc.board_sensors` icm42688p line |
| IMU1 on SPI4 | `spi.cpp` SPI4 entries; `bmi088 -s -b 4 -A/-G` lines |
| Baro on I2C1 | `i2c.cpp` `initI2CBusShared(1)`; baro start line |
| Motors M1-M4 | `timer_config.cpp` TIM1 channels, PE9/PE11/PE13/PE14; `DIRECT_PWM_OUTPUT_CHANNELS` |
| UART4 companion | `CONFIG_BOARD_SERIAL_TEL2`, `board.h` `GPIO_UART4_*`, defconfig `UART4_*` |
| GNSS | `CONFIG_BOARD_SERIAL_GPS1` (USART1) |
| RC | `CONFIG_BOARD_SERIAL_RC` (UART5), `RC_INPUT_PROTO` default |
| ESC telemetry | `CONFIG_BOARD_SERIAL_TEL3` (UART7 RX PE7) |
| Battery V / I | `board_config.h` `ADC_BATTERY_*_CHANNEL` (ADC12 ch 4 / 8) |
| LEDs | `GPIO_nLED_*` |
| microSD | `sdio.c`, defconfig SDMMC1 |

This table becomes the review checklist when the schematic exists.

## 5. Companion computer (Pi 5) integration

- Pi: serial device `/dev/ttyAMA0` on GPIO14/15 per the PX4 Raspberry Pi companion docs; application via MAVSDK (PX4's recommended library) or ROS 2.
- PX4: `MAV_1_CONFIG = TELEM2`, `SER_TEL2_BAUD = 921600`. For ROS 2 use uXRCE-DDS: `MAV_1_CONFIG = 0`, `UXRCE_DDS_CFG = 102`.
- Failsafe: the FC must keep flying or failsafe if the Pi stops. Configure the offboard / companion-loss and data-link-loss actions in PX4 (parameter names to be confirmed against the reference for the pinned PX4 release); validate by pulling the UART and power-cycling the Pi.
- Pi power: the Pi must run with the full USB current limit (see power_tree.md); otherwise the OAK-D Lite may brown out and the Pi, not the FC, is affected.

## 6. ESC protocol

`DRIVERS_DSHOT` is enabled in the reference. Protocol rate, bidirectional telemetry support and an ESC that matches (your concept mentions "Bluejay compatible") are **unverified**. Add pull-down resistors on motor signal lines so ESCs stay disarmed during MCU reset; a 2026-10-13 PX4 commit ("drive PWM outputs low at reset instead of input pull-up") shows this is an active concern upstream. Test props-off first.

## 7. Outstanding firmware work

1. Decide board vendor/model name and register a unique `board_id`.
2. Create `boards/roxx/fc-v1/` and make it build.
3. Add and test the ICM-42688-P and chosen baro start lines.
4. Rework buzzer, motor timers, battery calibration.
5. Bench-verify bootloader, SWD recovery, watchdog and brownout behaviour.
6. Confirm status on the PX4 supported-hardware list; decide whether to upstream the ROXX board.

## 8. Sources

- PX4 NuttX Board Porting Guide: https://docs.px4.io/main/en/hardware/porting_guide_nuttx
- PX4 Raspberry Pi companion setup: https://docs.px4.io/main/en/companion_computer/pixhawk_rpi.html
- PX4 repo, `boards/hkust/nxt-dual` (files listed in section 1) and `boards/px4/fmu-v6c`, `fmu-v6x`, `fmu-v6xrt`, `matek/h743-slim`, `holybro/kakuteh7`: https://github.com/PX4/PX4-Autopilot/tree/main/boards
- Commit history for the board: https://github.com/PX4/PX4-Autopilot/commits/main/boards/hkust/nxt-dual
- Vendor page: https://micoair.com/flightcontroller_nxtpx4v2/
