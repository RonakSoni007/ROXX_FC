# ROXX Flight Controller: Requirements and Assumptions

Status: **partial (Stage 2).** Fixed requirements are from the project brief and the Stage 2 instruction. Everything labelled ASSUMPTION or PROPOSAL needs your approval or a datasheet before it becomes a requirement.

Legend: **[FIXED]** stated by you. **[PROPOSAL]** my recommendation, awaiting approval. **[ASSUMPTION]** value I had to assume. **[VERIFIED]** checked against a cited source.

## 1. Fixed requirements

| ID | Requirement | Source |
|---|---|---|
| R-01 | New custom ROXX flight-controller PCB (the imported Nxt design is a reference only) | [FIXED] |
| R-02 | PX4 firmware; MCU must be on a verified PX4 support path | [FIXED] |
| R-03 | IMU, barometer and essential flight peripherals on the board | [FIXED] |
| R-04 | At least four independently controlled ESC outputs | [FIXED] |
| R-05 | Interfaces: external GNSS, RC receiver, telemetry, companion computer, debug, expansion | [FIXED] |
| R-06 | Stabilisation, sensing, motor control and essential failsafes run on the FC, never on the Pi | [FIXED] |
| R-07 | Raspberry Pi 5 over a UART/MAVLink link; high-level autonomy only | [FIXED] |
| R-08 | Luxonis OAK-D Lite on the Pi over USB; no camera data through the MCU | [FIXED] |
| R-09 | External GNSS over serial; no onboard GNSS; compass not assumed | [FIXED] |
| R-10 | Four BLDC motors via a 4-in-1 ESC or four ESCs; FC supplies control signals only | [FIXED] |
| R-11 | Separately engineered Pi 5 power path; Pi 5 V never fed from an unsuitable FC peripheral rail | [FIXED] |
| R-12 | Voltage and current sensing, protection, decoupling, noise control, deliberate grounding | [FIXED] |
| R-13 | Mark every deliverable complete / partial / blocked / awaiting verification | [FIXED] |

## 2. Derived requirements (from verified facts)

| ID | Requirement | Basis |
|---|---|---|
| D-01 | Pi 5 supply must be able to deliver 5.1 V at 5 A (25.5 W) | [VERIFIED] Raspberry Pi USB PD white paper: without a detected 5 V 5 A supply the Pi assumes 3 A and limits USB to 600 mA total |
| D-02 | The OAK-D Lite is powered from the Pi's USB port, so the Pi must run with the full USB current limit enabled (PD-negotiated, or `usb_max_current_enable` set in `config.txt` with a real 5 A supply) | [VERIFIED] OAK-D Lite datasheet: 5 V, 4 / 5 / 6 W min/typ/max; Pi white paper |
| D-03 | Companion link: dedicated UART with DMA, 3.3 V logic, MAVLink 2 at 921600 baud proposed | [VERIFIED] reference board enables DMA only on UART4 and defaults it to 921600; PX4 Pi docs use `MAV_1_CONFIG` + `SER_TEL2_BAUD` |
| D-04 | All four motor outputs on one timer group so they share one protocol and rate | [VERIFIED] PX4 timer groups share protocol; reference puts M1-M4 on TIM1 |
| D-05 | Board needs its own PX4 target and its own unique bootloader board ID | [VERIFIED] reference `firmware.prototype` still carries a copied ID (1013) and a Matek description |

## 3. Proposals awaiting your approval

| ID | Proposal | Why it needs you |
|---|---|---|
| P-01 | Battery input design range **3S-6S** (about 9 V empty to 25.2 V full); protection to be sized for transients above that | You have not stated the battery. Do not treat as fixed |
| P-02 | Rev A mandatory: STM32H743, two IMUs on separate SPI buses, one barometer, microSD, USB-C, SWD, buzzer, 4 motor outputs, GNSS UART, RC UART, telemetry UART, companion UART, ESC telemetry RX, battery V and I sensing, status LEDs | See architecture_decision_matrix.md section 4 |
| P-03 | Rev A optional / footprint-only: second GNSS UART, I2C4 expansion, SPI3 pads, motor outputs 5-6, INA228 monitor on the Pi branch | Cost / area trade |
| P-04 | Rev A deferred: CAN (FDCAN + transceivers), second barometer, ethernet/other buses | Not required by the brief; keeps rev A simple |
| P-05 | Connector family: JST-GH (Pixhawk-style) instead of the reference's JST-SH 1.0 mm | Mechanical and availability decision |

## 4. Assumptions that must be replaced by real data

| ID | Assumption | Replace with |
|---|---|---|
| A-01 | GNSS module draws up to 0.30 A at 5 V (incl. active antenna) | Selected module datasheet |
| A-02 | RC receiver 0.20 A, telemetry radio 0.50 A at 5 V | Selected hardware |
| A-03 | MCU rail current 0.35 A at 3.3 V including margin | STM32H743 datasheet, measured on bench |
| A-04 | microSD peak 0.15 A at 3.3 V | Card datasheet |
| A-05 | Pi 5 typical load about 10 W with camera streaming | Measured on your payload (community reports show 4 W idle to about 10 W) |
| A-06 | Buck efficiency 88-92 % | Chosen regulator datasheet and bench test |
| A-07 | ESC accepts 3.3 V logic and supports DShot | Chosen ESC datasheet. A "Bluejay-compatible" ESC runs open-source firmware for BLHeli_S-class hardware; its telemetry model (bidirectional DShot rather than a serial telemetry line) must be checked against PX4 |

## 5. Not established (not invented)

Battery chemistry/capacity, motor and ESC part numbers, motor current, GNSS module, RC protocol and receiver, telemetry radio, airframe mass, and the maximum FC board size.
