# ROXX Flight Controller: Preliminary Power Tree

Status: **partial (Stage 2).** All loads marked A are assumptions (see requirements.md section 4). No regulator is declared adequate; the numbers below show what each rail must achieve and which candidate parts fail on paper. Regulator part selection needs datasheets and is a Stage 3 task.

Source tags: [V] verified from a cited source this session. [A] assumption. [C] computed by me from the stated inputs.

## 1. Battery input (PROPOSAL P-01, needs approval)

| Pack | Empty 3.0 V/cell | Nominal 3.7 | Full 4.2 |
|---|---|---|---|
| 3S | 9.0 V | 11.1 V | 12.6 V |
| 4S | 12.0 V | 14.8 V | 16.8 V |
| 5S | 15.0 V | 18.5 V | 21.0 V |
| 6S | 18.0 V | 22.2 V | 25.2 V |

Proposed design range 3S-6S: operating 9-25.2 V [C]. Real packs sag under load and ESCs produce voltage spikes on the battery lines, so regulators and protection are sized above 25.2 V. Pack and ESC are not chosen, so no spike value is assumed.

Reference-design facts [V, schematic and distributor data]: Q1 AP40P05 P-FET reverse protection, D3 SMF30CA TVS, two MP9943GQ-Z bucks. Distributors disagree on the MP9943's input maximum (30 V on several listings, 36 V on others); several listings show long lead times or zero stock. **For 6S with ESC transients, a regulator rated 30 V is marginal.** A 40 V or higher rated regulator is recommended, subject to datasheet review.

## 2. Power tree

```
 BATTERY (3S-6S) --+-- ESC / motors (separate, high-current path, not through this PCB)
                   |
                   +-- [reverse-polarity FET + TVS + fuse/eFuse] -- VBAT_PROT
                         |
                         +-- Buck A (FC 5 V, ~3 A class) --- 5V_FC --+-- GNSS, RC, telemetry, I2C4 aux
                         |                                           +-- LDO / buck 3V3_CORE --- MCU, IMUs, baro
                         |                                           +-- LDO 3V3_PERIPH ------- microSD, flash
                         |
                         +-- Buck B (Pi 5.1 V, 5 A class) --- 5V1_PI --[ideal diode / ORing]-- Pi 5 (GPIO 5 V pins or USB-C)
                                                                      +-- (Pi USB) -- OAK-D Lite, powered by the Pi
 USB-C (bench) --[ideal diode]-- 5V_FC   (FC rails only, never the Pi rail)
 VBAT_PROT --[divider 10.1:1]-- PC4 (ADC12_INP4)       (battery voltage)
 current sensor out -----------PC5 (ADC12_INP8)         (battery current)
```

Grounding: single solid ground plane, ESC power return kept off the sensor area, Pi ground and FC ground joined at one deliberate star point near Buck B output [PROPOSAL]. Pi UART return runs next to the signal lines.

## 3. Raspberry Pi 5 path (Buck B)

Verified inputs:
- Raspberry Pi recommends 5.1 V 5 A (25.5 W). Without a detected 5 V 5 A supply the Pi assumes 3 A and limits total USB current to 600 mA, and USB boot is disabled [V: Raspberry Pi USB PD white paper; retailer and community pages agree].
- OAK-D Lite: 5 V, datasheet 4 / 5 / 6 W min / typ / max; vendor pages say up to about 5 W and 900 mA at 5 V from USB [V: Luxonis datasheet and product pages]. Worst case 6 W is about 1.18 A at 5.1 V [C].

| Case | Output | Current | Basis |
|---|---|---|---|
| Typical Pi 5 + camera streaming | about 10 W | about 1.96 A | [A] community measurement 4 W idle to about 10 W |
| OAK-D worst alone | 6 W | 1.18 A | [V] datasheet max |
| **Design maximum** | **25.5 W** | **5.0 A** | [V] Pi requirement |

Input current and loss at design maximum [C], for the efficiency range 88-92 % [A-06]:

| Battery | Input power | Input current | Loss in Buck B |
|---|---|---|---|
| 9 V | 27.7-29.0 W | 3.08-3.22 A | 2.2-3.5 W |
| 12.6 V | 27.7-29.0 W | 2.20-2.30 A | 2.2-3.5 W |
| 16.8 V | 27.7-29.0 W | 1.65-1.72 A | 2.2-3.5 W |
| 25.2 V | 27.7-29.0 W | 1.10-1.15 A | 2.2-3.5 W |

Typical 10 W load: loss 0.9-1.4 W [C].

Thermal: temperature rise is loss times thermal resistance. With 2.2 W loss and an assumed board-to-air resistance of 20 / 30 / 40 K/W the rise is about 44 / 66 / 88 K [C, resistance is an assumption]. This is why the regulator needs copper area, airflow (the concept shows a fan), and a thermal-shutdown margin; the figure is only valid once real thermal resistance is measured.

Requirements for Buck B:
1. 5.1 V output, at least 5 A continuous, remote-sense at the Pi connector, low ripple, soft-start, input rating at or above 40 V [PROPOSAL].
2. Transient: Pi 5 and USB devices produce load steps; use sufficient output capacitance and verify with a scope. Quantity not computed.
3. Current limit and over-temperature protection; reverse-current block so the Pi's USB-C and header supplies cannot back-feed each other.
4. Cable/connector rated for 5 A plus margin, with multiple power and ground pins.
5. Pi USB current limit: either the supply advertises 5 V 5 A through USB-C PD, or `usb_max_current_enable` is set on the Pi with a verified 5 A supply (white paper, element14 FAQ). If this is missed the OAK-D Lite may brown out because the USB limit is 600 mA.
6. Pi power is **never** taken from 5V_FC.

## 4. Flight-controller rails

Assumed loads [A]:

| Rail | Load | Current |
|---|---|---|
| 5V_FC | GNSS + active antenna | 0.30 A |
| 5V_FC | RC receiver | 0.20 A |
| 5V_FC | Telemetry radio | 0.50 A |
| 5V_FC | Buzzer + LEDs | 0.08 A |
| 5V_FC | I2C4 aux | 0.10 A |
| 3V3 | MCU incl. margin | 0.35 A |
| 3V3 | Two IMUs | 0.02 A |
| 3V3 | Barometer | 0.01 A |
| 3V3 | microSD peak | 0.15 A |
| 3V3 | Flash/misc | 0.02 A |

Totals [C]: **3V3 rail 0.55 A**; 5V_FC including the 3V3 conversion about **1.73 A** (8.7 W).

Findings:
- The reference uses RT9013-33GB LDOs noted as 500 mA. With these assumptions the 3V3 rail is 0.55 A, which is **10 % over a 500 mA part**. The assumption (A-03, A-04) is conservative, but the conclusion is that the ROXX 3V3 rail should be sized for at least 1 A, or split so the SD card has its own regulator. Decide after measuring a real MCU load.
- Buck A: 1.73 A against a 3 A class converter leaves about 42 % margin [C]. A 5 V to 3.3 V linear stage at 0.55 A dissipates about 0.93 W [C]; a small buck for 3V3 is a possible alternative if thermal margin is thin. Separate analog-quiet supply for IMUs and baro (LC or LDO from 3V3) is recommended.
- Buck A input power about 9.8 W at 88 % efficiency (loss about 1.2 W) [C].

Sensor supplies: IMU and baro from a filtered 3V3 branch (ferrite + LC), kept away from the Pi buck's switching loop.

## 5. Battery sensing

- Voltage: PC4 divider ratio 10.1:1 matches PX4 board defaults (`BAT1_V_DIV 10.1`). At 6S full (25.2 V) the ADC sees 2.50 V; full scale at 3.3 V is 33.3 V [C, V]. Needs a clamp and RC filter.
- Current: PC5 accepts the analog output of the ESC or an external power module. PX4 board default is 17 A/V (3.3 V gives 56.1 A) [V, C]; must be recalibrated for the chosen sensor.
- Optional: INA228 power monitor on the Pi branch via I2C. PX4's `fmu-v6c` build config enables an INA228 driver [V]; whether the ROXX target would enable it, and I2C bus allocation, is open.
- Total avionics (Pi design maximum plus FC) is about 38 W at the battery, or 4.24 A at 9 V, 2.58 A at 14.8 V, 1.51 A at 25.2 V [C]. Motor current is separate and is **not established**; do not run motor power through this PCB without a current budget.

## 6. Power-up, brownout and protection

| Item | Plan | Status |
|---|---|---|
| Reverse polarity | P-FET (reference) or ideal-diode controller | [PROPOSAL] |
| Surge | TVS plus regulator rated above clamp voltage | needs ESC transient data |
| USB | Schottky/ideal diode OR with 5V_FC | reference uses DSS34 diodes |
| Sequencing | MCU 3V3 before sensors enable; PX4 brownout behaviour verified in bench tests | not tested |
| MCU watchdog | CONFIG_WATCHDOG=y in the reference NuttX config | [V] enabled, behaviour not tested |
| Pi loss | PX4 offboard/companion-loss failsafe configured | parameters to confirm against the pinned PX4 release |

## 7. Unverified items

Datasheets for the MCU, IMUs, baro, regulators and GNSS were not retrieved this session. Nothing above is taken from them except where tagged [V] to a distributor listing or vendor page.
