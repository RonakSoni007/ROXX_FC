# ROXX Architecture Decision Matrix

Status: **complete for Stage 2 (recommendations, not approvals).**
Scores are my engineering judgement, 1 (poor) to 5 (good). They are not measurements. Facts are tagged [V] verified this session or [G] general knowledge not re-verified.

## 1. MCU

| Option | PX4 support path | Resources | Availability / assembly | Dev effort | Maintainability | Score |
|---|---|---|---|---|---|---|
| **A. STM32H743VIH6 (TFBGA100)** | [V] `boards/hkust/nxt-dual` builds this exact MCU; [V] H7 bootloader built from the same tree | [V] 480 MHz, 2 MB flash per reference; all needed UART/SPI/I2C/SDMMC/USB/timers already proven | BGA, 0.8 mm; fine-pitch via/trace rules used by reference are tight | Lowest: copy and adapt a working target | High: many H7 boards in tree | **22** |
| B. STM32H743VIT6 (LQFP100) | Same silicon family; pin names mostly shared | Same | Hand-solderable and inspectable | Low, but every pin AF must be re-checked: the reference spreadsheet notes the BGA pin arrangement differs | High | 21 |
| C. STM32H7 other (H753, H723) | [V] board files for other H7 boards exist (e.g. `px4/fmu-v6c`, `px4/fmu-v6x`, `matek/h743-slim`); per-device support and clocks not checked | H753 adds crypto; H723 smaller RAM [G] | [G] | Medium | Medium | 17 |
| D. NXP i.MX RT1176 | [V] `px4/fmu-v6xrt` exists in tree | Much more compute, external flash needed [G] | BGA, heavy layout | High | Medium | 14 |
| E. STM32F4/F7 | [G] older boards, tight flash for current PX4 | Smaller | Easy | Medium | Low (legacy) | 11 |

Recommendation: **A (STM32H743VIH6, TFBGA100)**. Fallback: B if BGA assembly or inspection is a blocker. Reason: a verified PX4 board target with a complete peripheral map already exists, and the brief rewards verified support over raw performance.

## 2. IMU

| Option | PX4 driver | Notes | Score |
|---|---|---|---|
| Dual BMI088 (as reference) | [V] `drivers/imu/bosch/bmi088` present and used by nxt-dual | Needs 2 CS + 2 DRDY per device (8 pins for two); zero firmware change; two identical parts share failure modes | 18 |
| **ICM-42688-P (IMU0) + BMI088 (IMU1)** | [V] `invensense/icm42688p` and `bosch/bmi088` both present; [V] `px4/fmu-v6c` lists both | Dissimilar redundancy; ICM has one CS and one INT, so frees pins; ICM footprint and STEP exist in the imported library but their licence is unverified; availability not checked | **21** |
| ICM-45686 | [V] driver directory exists | Newer; maturity and availability not checked | 14 |

Recommendation: **ICM-42688-P on SPI1 plus BMI088 on SPI4**, with dual-BMI088 as the pin-compatible fallback. Needs your approval (changes the pin map). Part availability must be checked before commit.

## 3. Barometer

| Option | PX4 driver | Notes | Score |
|---|---|---|---|
| SPL06 (as reference) | [V] `goertek/spl06` | Reference firmware starts `spl06`, yet one retailer page lists a DPS310 for the same product: **discrepancy, unresolved** | 15 |
| **BMP388** | [V] `drivers/barometer/bmp388` | Bosch; same vendor as IMU1 | **19** |
| DPS310 | [V] `drivers/barometer/dps310` | Infineon | 17 |
| MS5611 | [V] `drivers/barometer/ms5611`; [V] used in `px4/fmu-v6c` | Long PX4 heritage | 18 |

Recommendation: **BMP388 on I2C1** (shares reference wiring and bus), subject to availability check. One barometer in rev A; no second one justified by the brief.

## 4. Feature scope for revision A

| Feature | Decision | Reason |
|---|---|---|
| 4 motor outputs (TIM1) | Mandatory | R-04 |
| Motor outputs 5-6 (TIM2) | Optional (pads) | Servo / gimbal use; separate timer group |
| Buzzer on timer pin | **Mandatory** | Audible arming and failsafe; reference only has a GPIO pin, not a timer-driven tone |
| Dual IMU | Mandatory | Real redundancy; cost is modest |
| Second barometer | Defer | Not justified by the brief |
| CAN | **Defer to rev B** | No CAN device in the brief; GNSS is serial. Adds transceiver and pin work |
| Telemetry port | Mandatory (1) | R-05 |
| Second GNSS/serial and I2C4 | Optional connector | Cheap; I2C4 gives a compass path if needed later |
| SPI3 | Pads only | Reference leaves it unused |
| USB-C | Mandatory | PX4 console, firmware update, QGroundControl |
| microSD logging | Mandatory | Flight-log evidence for validation |
| ESC telemetry RX (UART7) | Mandatory | Depends on ESC choice (A-07) |
| Debug UART console (USART6) | Mandatory | Verified as the NuttX console in the reference code but not wired in its hardware |
| INA228 on Pi branch | Optional | PX4 has a verified `power_monitor/ina228` option |

## 5. Pi 5 power path

| Option | Pros | Cons | Score |
|---|---|---|---|
| **Dedicated on-board 5.1 V buck, 5 A, to the Pi** | Meets D-01; independent of FC rails | Heat (about 2.2-3.5 W loss at full load); needs a rated connector and Pi-side backfeed protection | **19** |
| Separate off-board BEC module | Heat off the board; simple | Not integrated; extra wiring and mass | 16 |
| Share the FC 5 V rail | Simplest | Violates R-11 and the 3 A rail class | 3 |

Recommendation: dedicated on-board buck, with the Pi fed through a connector rated for 5 A and an ideal-diode/ORing stage so the Pi's USB-C and the header cannot back-feed each other. Never power from both sources unless that is deliberately designed and tested.

## 6. Companion link

UART4 (PB8/PB9) at 921600, MAVLink 2, with PX4 `MAV_1_CONFIG = TELEM2`. [V] pins, DMA and baud default come from the reference board code. Add an optional USB path later only if needed.
