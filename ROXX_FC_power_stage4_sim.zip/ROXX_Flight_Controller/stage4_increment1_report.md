# ROXX Flight Controller — Stage 4, Increment 1 report (power subsystem)

Date: 2026-10-18 · Author: Arena agent (hardware architecture role) · Scope gate: power front-end only, **no PCB routing**

## 1. Checklist responses (user's increment-1 list)

1. **requirements.md / architecture.md with D-01…D-04** — present and unchanged since lock: `requirements.md` decision table rows D-01…D-04; `architecture.md` §7 impact paragraphs. Verified this session by grep (lines 53–56 and 98–101 respectively).
2. **Toolchain** — `kicad-cli version` prints exactly: `9.0.2`. Project is a native KiCad 9 project: `kicad/roxx_fc.kicad_pro` (meta.version 1), `roxx_fc.kicad_sch` format `(version 20250114)`, symbol library `roxx_power.kicad_sym` `(version 20241209)`. The KiCad-7 originals in `reference/` were never opened or migrated.
3. **Frozen electrical input range** — `power_tree.md` §7.1: min operating **12.0 V**, nominal **14.8 / 22.2 V**, max continuous **25.2 V** (6S full 4.20 V/cell), design continuous **26.0 V**, transient **+40 V / 1 ms (declared ASSUMPTION)**, buck UVLO **start 10.995 V / stop 9.513 V**.
4. **Corner calculations + TVS justification** — `power_tree.md` §7.2–7.4: Q1 loss table at 12/14.8/22.2/26 V; TVS chain standoff 30 V ≥ 26 V working → VBR 33.3–36.8 V → clamp 48.4 V @ 12.4 A vs 50 V capacitors (3.2 % margin) and 65 V buck abs-max; buck tON table at every corner incl. 40 V transient (250–833 ns vs 130 ns min); thermal corners (SYS_5V ΔT ≈ 52 K, CORE_3V3 ≈ 21 K, AP2112 PERIPH Tj ≈ 113 °C flagged marginal).
5. **Component-level power schematic** — `kicad/roxx_fc.kicad_sch` (171 instances): full MPNs, footprints, feedback/divider/compensation values, decoupling and protection as implemented; plot artifacts `kicad/plots/roxx_fc_power.pdf` / `.svg`.
6. **ERC actual report** — `kicad/erc_report.json` + `kicad/erc_report.txt`, produced by `kicad-cli sch erc roxx_fc.kicad_sch --format … --severity-all`: **0 errors, 0 warnings** (verbatim: "ERC messages: 0 Errors 0 Warnings"). History is disclosed, not hidden: the run sequence during integration produced 109 → 53 → 9 → 0 violations; every intermediate class was root-caused (invalid library header; three pin-coincidence shorts COMP_5V/VBAT_IN, GND/SS_5V, SYS_5V/COMP_3V3; single-pin-net label semantics on the EN stubs) and fixed in the generator. Netlist (`kicad/erc_netlist.net`, 31 nets) was audited net-by-net against design intent and re-diffed identical after the final cosmetic re-layout.
7. **Original preservation + complete updated project** — `reference/` re-verified this session: **101/101 SHA-256 match** against `audit/source_manifest.csv` (the two production PDFs live under an unzip-mangled UTF-8 folder name; content hashes match exactly). Updated project files: `kicad/{roxx_fc.kicad_pro, roxx_fc.kicad_sch, roxx_power.kicad_sym, sym-lib-table, fp-lib-table, roxx_fc.pretty/L_TDK_SPM6530T.kicad_mod, gen_power_sch.py, erc_report.*, erc_netlist.net, plots/}`.

## 2. Classification

**Completed (implemented in files):** power schematic netlist-clean and ERC-clean; reproducible generator; symbol library with 4 custom symbols + 8 rails; local footprint for SPM6530T-220M-HZ; docs updated (power_tree §7, interface_spec §4 D-03, BOM rows P01–P12, change_log).

**Calculated (datasheet maths, NOT measured):** all §7 numbers — UVLO divider, RT/fSW, tON margins, Type-2A compensation zero/pole, Q1 conduction loss and VGS clamp, TVS standoff/clamp chain, buck/LDO thermal rises, soft-start τ ≈ 10 ms.

**Tool-verified (actual tool output):** ERC 0/0 with `--severity-all`; netlist membership audit; symbol-library load via `kicad-cli sym export svg`; PDF/SVG plot; 101/101 SHA-256 of originals; KiCad 9.0.2 version string.

**Unresolved / assumptions (explicit):** +40 V/1 ms transient envelope assumed; aircraft surge environment undeclared (TVS residual risk documented); SPM6530T Isat 2.3 A (TDK) vs 1.7 A (distributor) discrepancy open; AP2112 PERIPH thermal marginal at 0.2 A/Ta 50 °C; loop stability computed not measured; EN-stub nets undriven until the MCU sheet lands in increment 2 (test points TP11–13 fitted, ERC-clean by construction); no DRC (no layout exists — routing is out of scope this increment); no bench, thermal, EMC or flight test of anything; **no flight-readiness claim is made or implied**.

## 3. Next increment (not started)

MCU/core sheet (STM32H743VIT6, dual-IMU sensor island per D-04, BMP388, W25Q128), interface sheets (GNSS/TELEM/RC per D-03/companion/debug), then whole-board ERC, then layout gate.

---

## Addendum (2026-10-18): SPICE verification pass and one schematic correction

1. **Correction found by simulation**: EN-clamp zeners D4/D6 were oriented K=VBUS_FC/A=EN; in breakdown this raises EN toward VBUS−4.7 V (21.3 V at 26 V in), violating the 5 V EN absolute max and defeating UVLO. Corrected to K=EN/A=GND, schematic regenerated, ERC re-run 0/0, plots regenerated. Net membership unchanged (31 nets).
2. **Simulation set** (`sim/`, ngspice 44.2): KiCad-netlist transpile + datasheet-parameterised models; 8 decks. Key sim-verified numbers: UVLO on/off 11.91/11.41 V (model band 0.50 V; design target from datasheet Eq. 2/3 is 11.00/9.51 V — the average model reproduces latch+hysteresis qualitatively, not the I1 offset; design values stand as calculated); regulated rails within 4 mV of setpoint across 12–26 V; Q1 VGS −11.90 V (clamp active, within ±20 V abs max); startup t90 3.45 ms, inrush 1.25 A; 0.1→1.0 A step undershoot 517 mV, settles 4.974 V; +40 V/1 ms transient clamps 48.26 V vs 48.4 V datasheet (cap margin 1.7 V — flagged); open-loop ripple matches hand calc ≤5%; ilmax 1.78 A @ 12 V corner vs SPM6530T Isat 1.7 A (DigiKey)/2.3 A (TDK) — OPEN discrepancy, now a margin question.
3. **Verification boundary unchanged**: ERC/netlist/plots tool-verified; §7 numbers calculated; sim numbers are model-level (average/behavioural), not bench; no loop-stability/phase-margin, thermal, EMC or flight verification.
