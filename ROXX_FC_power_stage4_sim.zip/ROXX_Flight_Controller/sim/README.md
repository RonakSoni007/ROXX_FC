# ROXX FC power stage — SPICE verification set (ngspice 44.2)

Status: **model-level verification, run 2026-10-18. All 8 decks complete. Not bench data. Not flight qualification.**

## What this is

- `gen_spice.py` — transpiles the **ERC-verified KiCad netlist** (`../kicad/erc_netlist.net`, ERC 0 errors / 0 warnings, KiCad 9.0.2) into `roxx_power.spice` (connectivity 1:1; R/C/L/D values and MPNs from the same tables as `gen_power_sch.py`). Test points / PWR_FLAGs omitted. Inductors split into L + DCR (182 mΩ).
- `models/roxx_models.lib` — datasheet-parameterised models:
  - SQ2309ES: LEVEL=1 PMOS, VTO −2 V, KP tuned so RDS(on) ≈ 0.33 Ω @ VGS −12 V; **bulk tied to source in the netlist** (discrete FET);
  - B360-13-F Schottky; BZX84-C12 / C4V7 zeners (BV/IBV/RS); SMBJ30A as fwd-diode + avalanche diode (BV 33.3 V, RS = Rdyn 1.218 Ω ⇒ Vc 48.4 V @ 12.4 A);
  - **TPS54160 system-average model**: EN UVLO latch with datasheet thresholds 1.25 V rise / 1.13 V fall + 2.9 µA hysteresis current injection, 0.8 V FB-pin trim (A=50, ±0.5 V bound), 1 A foldback, VIN−0.3 V dropout ceiling, 1 ms soft-start, power-conserving input current (Iout·Vout/Vin + 116 µA/1.3 µA), PWRGD ±8 % window. Reproduces regulation, UVLO, foldback, startup; **does not reproduce switching ripple, loop phase margin or SS ramp shape**.
  - **LDO model** (TPS7A2033 / AP2112K wrappers): VOUT, VDO·(I/ILIM) dropout, foldback, EN threshold, input-current mirror, Iq.
- `decks/` — A…F stimulus decks (full-board and corner decks). Each deck carries a `.save` vector list; `results/` holds `<deck>.log` (measurements), `<deck>.raw(.gz)` + `<deck>.raw.log` (waveforms), `results/csv/` decimated CSVs (+ full-rate `_zoom.csv` for F), `results/plots/` PNGs.

## Fidelity tiers (state per deck)

| Deck | Scope | Tier |
|---|---|---|
| A_uvlo_hyst | full board, battery triangle 8→26→8 V | behavioural regulators + real R/L/C/D/TVS/MOSFET models |
| B_startup | full board, 22.2 V step @ 1 ms | same |
| C_loadstep | full board, SYS_5V 0.1→1.0 A @ 5 ms | same |
| D_tvs_clamp | TVS + bulk bank + 1 Ω/10 µH source, +40 V/1 ms | real component models only |
| E_ldo_dropout | U3/U4 line-down 5→2.5 V | behavioural LDOs |
| F_vin12/22.2/26 | open-loop buck power stage (switching), duty per tON table | switching-level MOSFET/diode/L/C models |

## Results (this run, 2026-10-18)

| Deck | Measurement | Value | Reference / comment |
|---|---|---|---|
| A | UVLO on / off | 11.912 / 11.415 V | design (datasheet Eq. 2/3): 10.995 / 9.513 V. Model band 0.50 V vs 1.48 V designed: I1 pull-up offset not modelled — **design values stand as calculated**; model verifies latch + hysteresis behaviour, not exact thresholds |
| A | rails @ Vin 24.2 V | 5.004 / 3.302 / 3.299 / 3.300 V | within 4 mV of setpoints |
| A | Q1 VGS min | −11.902 V | BZX84-C12 clamp active; \|VGS\| < 20 V abs max ✓ |
| B | t10 / t90 / trise | 2.717 / 3.446 / 0.729 ms | soft-start dominated |
| B | inrush (min I(Vbat)) | 1.25 A | SS-limited; no bulk-cap inrush hazard |
| C | undershoot / settle | 4.485 V min, 4.974 V | 517 mV undershoot; average model (no loop bandwidth) ⇒ pessimistic vs real converter |
| C | battery current @ 1 A | 313 mA | power-consistent: (5·1.0 + 3.3·0.35 + 3.3·0.145)/22.2 ≈ 0.30 A ✓ |
| D | clamp peak | **48.264 V** @ 1.10 ms | datasheet Vc 48.4 V @ 12.4 A ✓; below 50 V cap rating with **1.7 V margin — flagged** |
| E | PERIPH @ Vin 5 / 3.6 V | 3.298 V both | regulating; dropout tracks to VIN−85 mV (2.582 V @ Vin 2.667 V) ✓ |
| E | IMU rails @ 5 / 3.4 V | 3.2998 V both | TPS7A20 VDO 4 mV @ 20 mA ✓ |
| F12/22/26 | ΔIL | 0.274 / 0.371 / 0.382 A | hand calc 0.265 / 0.352 / 0.367 A (≤ +5 %) ✓ |
| F12 | ilmax | **1.78 A** | exceeds DigiKey SPM6530T Isat 1.7 A; inside TDK 2.3 A — **OPEN supplier discrepancy, now a margin question** |
| F22 | vpp | 7.6 mV | 2×22 µF (3 mΩ ESR) + 100 nF |

## Re-running

```
cd sim/decks
for d in A_uvlo_hyst B_startup C_loadstep D_tvs_clamp E_ldo_dropout F_vin12 F_vin22.2 F_vin26; do
  ngspice -b -o ../results/$d.log $d.cir                              # measurements
  ngspice -b -r ../results/$d.raw -o ../results/$d.raw.log $d.cir     # waveforms (ascii)
done
cd .. && python3 parse_raw.py                                         # CSV + PNG
```
`.meas` output is suppressed when `-r` is used in batch mode ⇒ the double run is intentional.

## ngspice 44.2 pitfalls hit (probed, real)

1. Ternary `? :` inside `VALUE={}` and nested `MIN/MAX/LIMIT(...)` argument lists **misparsed** (probe: `MIN(LIMIT(3,1,2),4)` returned 4). All model expressions rewritten with arithmetic + `u()` only.
2. `G <n+> 0 VALUE={expr}` **sinks** current from n+ when expr > 0 (probe: relaxation integrator diverged to −1.7e52). All integrator signs set accordingly.
3. `PULSE` takes positional args (no `PW` keyword); `IF()` absent ⇒ ternary (but see 1); `.wrdata` unimplemented ⇒ rawfiles.
4. Bulk of discrete MOSFETs must be tied to source or the parasitic S–B diode conducts (354 A seen).
5. `set filetype=ascii` only inside `.control/.endc`.
6. Switch element order is `S name n+ n- nc+ nc- model`.

## Not verified by this set

Loop stability / phase margin / transient response of the real compensated converter (average model), switching-loss/thermal behaviour, EMC, layout parasitics, bench or flight anything. The +40 V/1 ms transient amplitude remains an **assumption** until the aircraft environment is declared.
