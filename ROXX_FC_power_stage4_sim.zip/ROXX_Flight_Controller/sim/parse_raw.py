#!/usr/bin/env python3
"""Parse ngspice ASCII rawfiles -> decimated CSV (results/csv) + PNG plots (results/plots).
No external deps for parsing; matplotlib for plots."""
import os, glob, csv, sys
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")

def parse_ascii_raw(path):
    with open(path) as f:
        lines = f.read().splitlines()
    nv = np_ = None; varnames = []; i = 0
    while i < len(lines):
        L = lines[i]
        if L.startswith("No. Variables:"): nv = int(L.split(":")[1])
        elif L.startswith("No. Points:"): np_ = int(L.split(":")[1])
        elif L == "Variables:":
            for j in range(nv):
                varnames.append(lines[i+1+j].split()[1])
            i += nv
        elif L == "Values:":
            i += 1; break
        i += 1
    data = [[] for _ in range(nv)]
    k = 0
    while i < len(lines) and k < np_:
        L = lines[i].strip()
        if not L: i += 1; continue
        if "\t" in lines[i] and lines[i][0].isspace() == False and lines[i].split("\t")[0].isdigit():
            # start of a point: "idx<TAB>v0"
            parts = [p for p in lines[i].split("\t") if p.strip() != ""]
            data[0].append(float(parts[1])); i += 1
            for v in range(1, nv):
                data[v].append(float(lines[i].strip())); i += 1
            k += 1
        else:
            i += 1
    return varnames, data

def decimate(data, maxpts=4000):
    n = len(data[0])
    if n <= maxpts: return data, list(range(n))
    step = n // maxpts
    idx = list(range(0, n, step))
    return [[c[i] for i in idx] for c in data], idx

PANELS = {
 "A_uvlo_hyst": [("Battery sweep vs time", ["v(n_vbat_in)","v(n_vbus_fc)"]),
                 ("Regulated rails", ["v(n_sys_5v)","v(n_core_3v3)","v(n_periph_3v3)"]),
                 ("EN pins (UVLO)", ["v(n_en_5v)","v(n_en_3v3)"]),
                 ("Q1 VGS (zener-clamped)", ["v(nvgs)"])],
 "B_startup":   [("Startup: bus and rails", ["v(n_vbus_fc)","v(n_sys_5v)","v(n_core_3v3)","v(n_periph_3v3)"]),
                 ("Battery current", ["i(vbat)"])],
 "C_loadstep":  [("SYS_5V load step 0.1->1.0 A", ["v(n_sys_5v)"]),
                 ("Battery current", ["i(vbat)"]),
                 ("Buck U1 inductor/output current", ["i(v.xu1.vam)"])],
 "D_tvs_clamp": [("+40V/1ms transient: source vs clamped bus", ["v(nsrc)","v(n_vbus_fc)"]),
                 ("Source current", ["i(vsrc)"])],
 "E_ldo_dropout": [("LDO dropout sweep", ["v(vin33)","v(vper)","v(vimu)"])],
 "F_vin12":     [("Inductor current (full)", ["i(lout)"]),("Output voltage (full)", ["v(out)"]),
                 ("Zoom: i(lout), 10 cycles", ["i(lout)"]),("Zoom: v(out), 10 cycles", ["v(out)"])],
 "F_vin22.2":   [("Inductor current (full)", ["i(lout)"]),("Output voltage (full)", ["v(out)"]),
                 ("Zoom: i(lout), 10 cycles", ["i(lout)"]),("Zoom: v(out), 10 cycles", ["v(out)"])],
 "F_vin26":     [("Inductor current (full)", ["i(lout)"]),("Output voltage (full)", ["v(out)"]),
                 ("Zoom: i(lout), 10 cycles", ["i(lout)"]),("Zoom: v(out), 10 cycles", ["v(out)"])],
}
ZOOM = (2.99e-3, 3.012e-3)

def plot(deck, names, data, outpng):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    panels = PANELS[deck]
    fig, axes = plt.subplots(len(panels), 1, figsize=(9, 2.4*len(panels)), sharex=False)
    if len(panels) == 1: axes = [axes]
    t = data[0]
    for ax, (title, sigs) in zip(axes, panels):
        zoom = title.startswith("Zoom")
        for s in sigs:
            if s not in names: continue
            y = data[names.index(s)]
            if zoom:
                sel = [i for i,tt in enumerate(t) if ZOOM[0] <= tt <= ZOOM[1]]
                ax.plot([t[i]*1e3 for i in sel], [y[i] for i in sel], lw=0.9, label=s)
            else:
                ax.plot([tt*1e3 for tt in t], y, lw=0.9, label=s)
        ax.set_title(deck + " - " + title, fontsize=9)
        ax.grid(True, alpha=0.3); ax.legend(fontsize=7, loc="best")
        ax.set_xlabel("time [ms]", fontsize=8); ax.tick_params(labelsize=7)
    fig.tight_layout(); fig.savefig(outpng, dpi=130); plt.close(fig)

os.makedirs(os.path.join(RES,"csv"), exist_ok=True)
os.makedirs(os.path.join(RES,"plots"), exist_ok=True)
for raw in sorted(glob.glob(os.path.join(RES,"*.raw"))):
    deck = os.path.basename(raw)[:-4]
    names, data = parse_ascii_raw(raw)
    if not data[0]: print("EMPTY", deck); continue
    d2, idx = decimate(data)
    with open(os.path.join(RES,"csv",deck+".csv"),"w",newline="") as f:
        w = csv.writer(f); w.writerow(["time_s"]+names[1:])
        for r in zip(*d2): w.writerow(["%.9g"%x for x in r])
    # extra full-rate zoom CSV for F decks
    if deck.startswith("F_"):
        sel = [i for i,tt in enumerate(data[0]) if ZOOM[0] <= tt <= ZOOM[1]]
        with open(os.path.join(RES,"csv",deck+"_zoom.csv"),"w",newline="") as f:
            w = csv.writer(f); w.writerow(["time_s"]+names[1:])
            for i in sel: w.writerow(["%.9g"%data[c][i] for c in range(len(names))])
    plot(deck, names, d2, os.path.join(RES,"plots",deck+".png"))
    print(deck, len(data[0]), "pts ->", len(d2[0]), "csv rows, plot ok")
